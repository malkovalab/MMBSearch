	
	#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <sys/wait.h>
#include <stdlib.h>
#include <algorithm>
#include <limits.h>
#include <ctime>
#include <cmath>

using namespace std;

#define STATE_1 0
#define RIGHT_ANCHORED 1
#define LEFT_ANCHORED 2
#define UNKNOWN 3



#define STATE_LEFT 0
#define STATE_BIR 1
#define STATE_RIGHT 2

	
	int main(){
	string reference = "GGATAGAAGATGGATTGATGGATATAGATACATGATGGATGGATGGATAGGTGATAATGAATAGACAGATGATGGATGGATGGATAGGTGATACATGGGTAGATGGGTGGAGGGATTGATAGATGATGGATGGATAGATGATGGATGGATAGATGGACAGAAGATGAATGGATATATGATGGATGGATGGATGGATGAGTAGATGGATGGATGGATGGT";
	string birRegion = "GGATAGAAGATGGATTGATGGATATAGATACATGATGGATGGATGGATAGGTGATAATGAATAGACAGATGATGGATGGATGGATAGGTGATACATGGGTA-A-------AGGGA--G---G--GAGGGATGGATAGATGATGGATGGATAGATGGACAGAAGATGAATGGATATATGATGGATGGATGGATGGATGAGTAGATGGATGGATGGATGGT";
	
	long long int iMissCount = 2; //confDB.getKey("missCount").intVal; // 3
	long long int iHitCount = 5; //confDB.getKey("hitCount").intVal; // 4
	long long int iMinBirLength = 9; //confDB.getkey("minBirLength").intVal;
	long long int iRefPos = -1;
	long long int iLastPos = 0;
	long long int length = birRegion.length();
	long long int iMisses = 0;
	long long int iHits = 0;
	long long int start = 0;
	long long int end = 0;
	bool isGood = false;

	long long int nState = STATE_LEFT;

	for (long long int i = 0; i < length; ++i){
		++iRefPos;

		switch (nState) {
		case STATE_LEFT:
			if (reference[iRefPos] == birRegion[i] || reference[iRefPos] == 'N' || birRegion[i] == 'N'){
				++iHits;
				iMisses = 0;
				cout<<"1- State_Left: i:"<<i<<"  and ihits:"<<iHits<<endl;
				cout<<"ref: "<<reference[iRefPos]<<"  and bir: "<<birRegion[i]<<endl;
			}
			else{
				if (iMisses == 0)
					iLastPos = i;
				++iMisses;
				cout<<"2- State_Left:  i:"<<i<<"  and ihits:"<<iHits<<"  and iMisses:"<<iMisses<<"  and ilastPos: "<<iLastPos<<endl;
				cout<<"ref: "<<reference[iRefPos]<<"  and bir: "<<birRegion[i]<<endl;
			}
			if (iMisses == iMissCount){
				iHits = 0;
				nState = STATE_BIR;
				start = iLastPos;
				cout<<"3- State_Left:  i:"<<i<<"  and  change to State_Bir, and start :"<<start<<endl;
				cout<<"ref: "<<reference[iRefPos]<<"  and bir: "<<birRegion[i]<<endl;
			}
			break;
		case STATE_BIR:
			if (reference[iRefPos] != birRegion[i])
			{
				++iMisses;
				iHits = 0;
				cout<<"1- State_Bir: i:"<<i<<"  and  ihits:"<<iHits<<"  and iMisses:"<<iMisses<<endl;
				cout<<"ref: "<<reference[iRefPos]<<"  and bir: "<<birRegion[i]<<endl;
			}
			else
			{
				if (iHits == 0)
					iLastPos = i;
				++iHits;
				cout<<"2- State_Bir:  i:"<<i<<"  and  ihits:"<<iHits<<"  and iMisses:"<<iMisses<<"  and ilastPos: "<<iLastPos<<endl;
				cout<<"ref: "<<reference[iRefPos]<<"  and bir: "<<birRegion[i]<<endl;
			}
			if (iHits == iHitCount)
			{
				if ((iLastPos - start) >= iMinBirLength)
				{
					nState = STATE_RIGHT;
					end = iLastPos - 1;
					isGood = true;
					cout<<"3- State_Bir:  i:"<<i<<"  and  isGood is true, transit to state_Right, ihits:"<<iHits<<"  and iMisses:"<<iMisses<<"  and ilastPos: "<<iLastPos<<endl;
				}
				else
				{
					if ((iLastPos - start) < iMinBirLength)
						nState = STATE_LEFT;
						cout<<"3- State_Bir:  i:"<<i<<"  and  isGood is false, transit to state_Left, ihits:"<<iHits<<"  and iMisses:"<<iMisses<<"  and ilastPos: "<<iLastPos<<endl;
				}
			}
			break;
		case STATE_RIGHT:
			// do nothing
			cout<<"state_right: ihits:"<<iHits<<"  and iMisses:"<<iMisses<<"  and ilastPos: "<<iLastPos<<endl;
			cout<<"ref: "<<reference[iRefPos]<<"  and bir: "<<birRegion[i]<<endl;
			break;
		}
	}

	if (isGood){
		//Need to add here that if the insertion has "-" character, exclude the "-" and recalculate length of insertion. If insertion is now less than iMinBirLength, it should be isGood = false. This should be enough to remove all deletions. 
		cout<<"Good\n";
		cout<<" start position: "<<start;
		cout<<" end position: "<<end;
		/*vCandidateRegions[curr].bBirCandidateFound = true;
		vCandidateRegions[curr].sBir = birRegion.substr(start, end - start + 1);
		vCandidateRegions[curr].iBirStart = st + start;
		vCandidateRegions[curr].iBirEnd = st + end;
		vCandidateRegions[curr].iBirLength = end - start + 1;
		*/
	} else {
		cout<<"Not good\n";
                cout<<" start position: "<<start;
                cout<<" end position: "<<end;
		/*vCandidateRegions[curr].bBirCandidateFound = false;
		*/
	}
	
}
