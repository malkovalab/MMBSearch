#include<iostream>

using namespace std;

int main(){

size_t x = 4;
int q = x;
size_t m = 6;
int y = m;
//y++;
cout<<(q-y)<<endl;
int z = x-y;
cout<<z<<endl;

return 0;
}
