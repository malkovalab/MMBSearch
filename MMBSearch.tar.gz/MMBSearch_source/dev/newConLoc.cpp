
void consolidateLocations(){
	cout << "\nConsolidating read locations start..." << endl;
	fLogFileOut << "\nConsolidating read locations start..." << endl;

	// TODO Find better way to consolidate, maybe based on stdev and discard ones that aren't (ie through out outliers)
	long long int iLastEndLoc = 0;
	 long long int iMinConsolidate = confDB.getKey("minConsolidate").intVal; // the minimum number of reads to consolidate, otherwise don't add to vector
long long int iMaxConsolidate = confDB.getKey("maxConsolidate").intVal; // the max number of reads to consolidate in a single cluster
	vector<t_consolidated> curr;
	long long int iNumReads = 0;
	long long int iSkippedCluster = 0;

	long long int iChr = (confDB.getKey("chromosome").intVal == 0 ? 0 : confDB.getKey("chromosome").intVal - 1); // get the user specified chromoome
	bool bOnlyOneChr = (confDB.getKey("chromosome").intVal != 0 ? true :false);
	long long int sizeCan = vCandidateReads.size();
	long long int fivePercent = sizeCan / 20;
	string sHalfReadClusters = confDB.getKey("clusterFile").stringVal;
	
	/* new initializations for the new clustering scheme: cluster based on anchor side instead of intersection only*/
	bool first = true;
	bool curr_left_anchored = true; 
	bool prev_left_anchored = true;
	vector<t_consolidated> merged; //to merge subclusters when needed
	//to save indeces of previous and next subclusters
	int prevInd;
	int nextInd;

	//Make a new vector to save subclusters
	vector<vector <t_consolidated> > vConsTemp;
	vector<vector <t_consolidated> > vConsRev;
	cout << "Chromsome: " << iChr << endl;
	
	 //for loop to consolidate subclusters of the same anchored direction in vConsTemp
	for (long long int i = 0; i < sizeCan; ++i){
		if (i % fivePercent == 0)
			cout << "\tcandidateRead: " << i << " of " << sizeCan << " on chromosome " << iChr << " (" << ((i * 100) / sizeCan) << "%)" << endl;
		if (vCandidateReads[i].iChromosome < iChr)
			continue;
		
		/******************************************
						CASES
		/******************************************/ 
		/// Case 1 & 2: 1) We jumped to next chromosome;
		/////////////// 2) we reached max numer of reads in a cluster
		//// in each case, we need to check if we already have enough reads to form a cluster or not; 
		/// if yes, write a new cluster, and start a fresh one; if not, erase previous candidate cluster due to insufficient reads, and a start a new one  
		///// Case 3: we reached a disconnected region--no overlapping with previous cluster.
		/////Case 4: We reached a read anchored opposite to the previous read (subcluster).
		if (vCandidateReads[i].iChromosome == iChr+1 || curr.size() == iMaxConsolidate || vCandidateReads[i].iParentStart > iLastEndLoc || curr_left_anchored != left_anchored(vCandidateReads[i]) ){ 
			
			//we use subcluster iff its size is larger than 2 (maybe needs tobe changed to 3
			if(curr.size()>2)
				vConsTemp.push_back(curr);
				
			curr.clear();
			if(vCandidateReads[i].iChromosome == iChr+1)
				iChr++;
			
			curr.push_back(vCandidateReads[i]);
			curr_left_anchored = left_anchored(vCandidateReads[i]);
			iLastEndLoc = vCandidateReads[i].iParentStart + vCandidateReads[i].sParentRead.length() - 1;
		}
		else{
			curr.push_back(vCandidateReads[i]);
			iLastEndLoc = vCandidateReads[i].iParentStart + vCandidateReads[i].sParentRead.length() - 1;
		}
	} //End of first for loop to consolidate subclusters of the same anchored direction in vConsTemp
			
	
	//while loop for loop to flip the order of the subclusters from vConsTemp and save them into vConsRev
	while(vConsTemp.size()>0){
		vConsRev.push_back(vConsTemp[vConsTemp.size()-1]);
		vConsTemp.pop_back();		
	}// End of second while loop to flip the order of the subclusters from vConsTemp and save them into vConsRev
	
	cout<<"Finishd reversing the vector storing the subclusters......and its isze is "<<vConsRev.size()<<"\n";
		/*************************** Merging subclusters Cases *************************/
	//case 1: prev is left:
	//      case 1.1:   if current is left  and it intersects next right and merged size is larger than min cluster: 
	//						merge both, and push; change previous to be current+1, and current to current +2.
	//      case 1.2: as previous case, except that left and next right do not make it as a whole cluster:
	//					 delete prev, and make prev current, and current = current+1
	//		case 1.3: as previous except that they do not intersect: 
	//					if previous size is enough as a whole cluster, push it; otherwise do not push, just update prev=curre, and curr = curr+1; 
	//		case 1.4: if previous is left and current is left.
	//					if intersect, merge and move indexes; if not, and if prev size is enough as a whole, push it, prev=curre, and curr = curr+1;

	//case 2: current is right,
	//		case 2.1: if current is right, and intersect:
	//					merge;
	//		case 2.2: if current is right and does not intersect OR current is left:
	//					and size is enough --> push and advance indexes
	
	//NOTE: we start from the next to last one (i) and compare it to its next, and merge if ok
	 prevInd = vConsRev.size()-1;
	 bool prevLeftAnch ;
	 int currInd = vConsRev.size()-2;
	 bool currLeftAnch;
	 int combinedSize;
	 int singleSize;
	while(currInd>=0){
		//cout<<"prevInd "<<prevInd<<" and currInd "<<currInd<<endl;
		currLeftAnch = left_anchored(vConsRev[currInd][0]);
		prevLeftAnch = left_anchored(vConsRev[prevInd][0]);
		combinedSize = vConsRev[prevInd].size() + vConsRev[currInd].size();
		singleSize = vConsRev[prevInd].size(); //we only save the previous
		//case 1:
		if(prevLeftAnch == true ){ //previous is left
			//case 1.1: 
			if(currLeftAnch == false &&  reads_intersect(vConsRev[prevInd][vConsRev[prevInd].size()-1], vConsRev[currInd][0] ) && ( (combinedSize >= iMinConsolidate && combinedSize<=iMaxConsolidate) || ( merged.size() >= iMinConsolidate && merged.size() <=iMaxConsolidate) ) ){
				//if merged has something in it, we 
				if(merged.size() == 0) //assumption is 
					merged.insert(merged.end(), vConsRev[prevInd].begin(), vConsRev[prevInd].end() );
				
				merged.insert(merged.end(), vConsRev[currInd].begin(), vConsRev[currInd].end() );
				vConsolidated.push_back(merged);
				merged.clear();
				
				prevInd = currInd-1;
				currInd-= 2;
			}
			else if(currLeftAnch == false &&  reads_intersect(vConsRev[prevInd][vConsRev[prevInd].size()-1], vConsRev[currInd][0] ) && combinedSize < iMinConsolidate ){
				prevInd = currInd;
				currInd -= 1; 
				merged.clear();
			}
			else if(currLeftAnch == false &&  !(reads_intersect(vConsRev[prevInd][vConsRev[prevInd].size()-1], vConsRev[currInd][0]) ) ){
					if(singleSize >= iMinConsolidate && singleSize <= iMaxConsolidate ){
						vConsolidated.push_back(vConsRev[prevInd]);
					}
					prevInd = currInd; //we have to move prevInd and currInd anyway
					currInd -= 1; 
					merged.clear();
			}
			else if(currLeftAnch == true && (reads_intersect(vConsRev[prevInd][vConsRev[prevInd].size()-1], vConsRev[currInd][0]) ) ){
				if(merged.size() == 0)
					merged.insert(merged.end(), vConsRev[prevInd].begin(), vConsRev[prevInd].end() );
				//we only merged previous if it was not merged before.
				merged.insert(merged.end(), vConsRev[currInd].begin(), vConsRev[currInd].end() );
				prevInd = currInd;
				currInd--;
			}
			else if(currLeftAnch == true &&  !(reads_intersect(vConsRev[prevInd][vConsRev[prevInd].size()-1], vConsRev[currInd][0]) ) ){
				
				if(merged.size()>0 && merged.size() >= iMinConsolidate && merged.size() <= iMaxConsolidate){
					vConsolidated.push_back(merged);
				}
				else if(singleSize >= iMinConsolidate && singleSize <= iMaxConsolidate){
					vConsolidated.push_back(vConsRev[prevInd]);
				}
				merged.clear();
				prevInd = currInd;
				currInd--;
			}
		}
		else { //previous is right
			if( currLeftAnch == false &&  reads_intersect(vConsRev[prevInd][vConsRev[prevInd].size()-1], vConsRev[currInd][0] ) ){
				if(merged.size() ==0)
					merged.insert(merged.end(), vConsRev[prevInd].begin(), vConsRev[prevInd].end() );
				merged.insert(merged.end(), vConsRev[currInd].begin(), vConsRev[currInd].end() );
			}
			else { // current is right and does not intersect OR current is left
				if(merged.size() >0 && merged.size() >= iMinConsolidate && merged.size() <= iMaxConsolidate){
					vConsolidated.push_back(merged);
				}
				else if( singleSize >= iMinConsolidate && singleSize <= iMaxConsolidate ){
					vConsolidated.push_back(vConsRev[prevInd]);
				}
				merged.clear();
				
			}
			prevInd = currInd;
			currInd--;
		}
		//now, delete the end of the vector as long as its index is larger than prevInd
			/*while( prevInd < vConsRev.size()-1 ){
				vConsRev.pop_back();
			} */
	}//End of third loop to merge subclusters and add them to vConsolidated

	fLogFileOut << "Number clusters skipped: " << iSkippedCluster << endl;
	cout << "\nNumber reads after consolidation: " << iNumReads << endl;
	fLogFileOut << "Number reads after consolidation: " << iNumReads << endl;
	cout << "Number of clusters: " << vConsolidated.size() << endl;
	fLogFileOut << "Number of clusters: " << vConsolidated.size() << endl;

	// Now the program will print out the consolidate read locations
	// A MySQL and Perl script is required to parse the data to further the program
	// The program will now exit
	fLogFileOut << "\nPrinting half_read_clusters.txt" << endl;
	ofstream output;
	output.open((sProjectDirectory + sHalfReadClusters.c_str()).c_str());
	long long int size2 = 0;
	for (long long int i = 0; i < vConsolidated.size(); ++i){
		size2 = vConsolidated[i].size();
		for (long long int j = 0; j < size2; ++j){
			output << vConsolidated[i].at(j).sReadName << "\t" << vConsolidated[i].at(j).sParentRead << "\t" << vConsolidated[i].at(j).iParentStart << "\t" << vConsolidated[i].at(j).iChromosome << "\t"<< i << endl;
		}
	}
	output.close();
	fLogFileOut << "\nCluster time = " << (long long int)time(NULL)-time0 << endl;

}


