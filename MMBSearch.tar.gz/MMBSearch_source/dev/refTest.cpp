#include<iostream>
#include<vector>

using namespace std;

struct node{
int value;
node* next;
node(int v){
   value = v;
   next = NULL;
   }
};



int main(){

vector<node*> vec;
vec.push_back(new node(1));
vec.push_back(new node(2));


return 0;
}