
	
   #include <stdio.h>
   #include <stdexcept>
   #include<string.h>
   #include <iostream>
   #include <fstream>
   #include <map>
   #include <vector>
   #include <sstream>
   #include <sys/wait.h>
   #include <stdlib.h>
   #include <sstream>
	

using namespace std;

   string exec(const char* cmd) {
       char buffer[128];
       string result = "";
       FILE* pipe = popen(cmd, "r");
       if (!pipe) throw runtime_error("popen() failed!");
       try {
      while (!feof(pipe)) {
          if (fgets(buffer, 128, pipe) != NULL)
         result += buffer;
      }
       } catch (...) {
      pclose(pipe);
      throw;
       }
       pclose(pipe);
       return result;
   }

int main(){
	 string token="";
	 string seq1 = "";
	string seq2 = "";

		string command = "needle -asequence s1.txt -bsequence s2.txt -gapopen 100 -gapextend 10 -auto -outfile waterOut.water; cat  waterOut.water | grep -v '#' | grep Seq* ";
	 		string	result = exec(command.c_str()); //this function will catch and return the sequences printed to stdout
				//cout<<"Result:\n"<<result<<endl;
	 			//the listed sequences are saved in result
	 			istringstream iss(result);
	 			while(iss>>token){
	 				if(token.compare("Seq1") == 0 ){
	 					iss>>token;
	 					iss>>token;
	 					//seq1 = seq1+token.substr(0, token.size()-1);
	 					seq1 = seq1+token;
	 					iss>>token;
	 				}
	 				
	 				else if(token.compare("Seq2") == 0 ){
	 					iss>>token;
	 					iss>>token;
	 					//seq2 = seq2+token.substr(0, token.size()-1);
	 					seq2 = seq2+token;
	 					iss>>token;
	 				}
	 				
	 				
	 			}//end while
	 			/////DEBUGGING		

		string	sConsensus = ""; 
	 			for(int v=0; v<seq1.size(); v++){
					if(2 < 5){
	 					if(seq1[v]!='-')
	 						sConsensus +=seq1[v];
	 					else 	
	 						sConsensus +=seq2[v];
	 					}
	 				else{
	 					if(seq2[v]!='-')
	 						sConsensus +=seq2[v];
	 					else 	
	 						sConsensus +=seq1[v];
	 				}
	 			}
	 			
	 			cout<<sConsensus<<endl;
	 			
	 			
	 return 0;
	 }