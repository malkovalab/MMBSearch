
/*
 * ************************************************************
 * consolidateLocations
 *
 * This function takes all the candidate regions and groups them together by the starting location of the unaligned read. If
 * there is any overlap between the reads, then they will be grouped together.
 *
 * A config.txt parameter (minConsolidate) determines how many reads need to be used to consolidate.
 */
void consolidateLocations(){
	cout << "\nConsolidating read locations start..." << endl;
	fLogFileOut << "\nConsolidating read locations start..." << endl;

	// TODO Find better way to consolidate, maybe based on stdev and discard ones that aren't (ie through out outliers)
	long long int iLastEndLoc = 0;
	 long long int iMinConsolidate = confDB.getKey("minConsolidate").intVal; // the minimum number of reads to consolidate, otherwise don't add to vector
long long int iMaxConsolidate = confDB.getKey("maxConsolidate").intVal; // the max number of reads to consolidate in a single cluster
	vector<t_consolidated> curr;
	long long int iNumReads = 0;
	long long int iSkippedCluster = 0;

	long long int iChr = (confDB.getKey("chromosome").intVal == 0 ? 0 : confDB.getKey("chromosome").intVal - 1); // get the user specified chromoome
	bool bOnlyOneChr = (confDB.getKey("chromosome").intVal != 0 ? true :false);
	long long int sizeCan = vCandidateReads.size();
	long long int fivePercent = sizeCan / 20;
	string sHalfReadClusters = confDB.getKey("clusterFile").stringVal;
	
	/* new initializations for the new clustering scheme: cluster based on anchor side instead of intersection only*/
	bool first = true;
	bool curr_left_anchored = true; 
	bool prev_left_anchored = true;
	vector<t_consolidated> prev_vector; //to save the left anchored subcluster
	vector<t_consolidated> right_vector; //to save the right anchored subcluster

	cout << "Chromsome: " << iChr << endl;
	for (long long int i = 0; i < sizeCan; ++i){
		if (i % fivePercent == 0)
			cout << "\tcandidateRead: " << i << " of " << sizeCan << " on chromosome " << iChr << " (" << ((i * 100) / sizeCan) << "%)" << endl;
		if (vCandidateReads[i].iChromosome < iChr)
			continue;
		if(vCandidateReads[i].iChromosome == iChr+1 ) //increment only if we jumped to a new chromosome
		{       ++iChr; 
			cout << "\nChromsome: " << iChr << endl;
		}
		if(first){ //this is to initialize correctly the very first subcluster type
			curr_left_anchored = left_anchored(vCandidateReads[i]);
			prev_left_anchored = !(curr_left_anchored);
			first = false;
		}
/******************************************
				CASES
/******************************************/ 
/// Case 1 & 2: 1) We jumped to next chromosome;----Implemented above
/////////////// 2) we reached max numer of reads in a cluster
//// in each case, we need to check if we already have enough reads to form a cluster or not; 
	/// if yes, write a new cluster, and start a fresh one; if not, erase previous candidate cluster due to insufficient reads, and a start a new one  
///// Case 3: we reached a disconnected region--no overlapping with previous cluster.
/////Case 4: We reached a read anchored opposite to the previous read (subcluster).
		if ( curr.size() == iMaxConsolidate || vCandidateReads[i].iParentStart > iLastEndLoc || curr_left_anchored != left_anchored(vCandidateReads[i]) ){ 
			//if current size of curr vector is less than subcluster size, just get rid of it.
			if(curr.size() < confDB.getKey("minSubCluster").intVal){
				curr.clear();
				curr.push_back(vCandidateReads[i]);
				curr_left_anchored = left_anchored(vCandidateReads[i]);
				iLastEndLoc = vCandidateReads[i].iParentStart + vCandidateReads[i].sParentRead.length() - 1;
				++iSkippedCluster;
				continue;
			}
			//case 1: we have right anchored vector, and prev_vector has elements
			if(curr_left_anchored !=true ){ //we have right subcluster in curr, and always we have left in prev_vector
			//if prev_vector size is larger than zero, merge subclusters
				if(prev_vector.size() > 0){
					//merge left with right (curr) iff they intersect
					if( reads_intersect(prev_vector[prev_vector.size()-1], curr[0])){//intersect
						curr.insert(curr.begin(), prev_vector.begin(), prev_vector.end());
						prev_vector.clear();
					}
					else{ //does not intersect: push previous first as a seprate cluster
						if((prev_vector.size()) >= iMinConsolidate && (prev_vector.size()) <= iMaxConsolidate  ){
							vConsolidated.push_back(prev_vector);
							iNumReads += prev_vector.size();
							prev_vector.clear();
						}
					}
				}
				if((curr.size() ) >= iMinConsolidate && (curr.size() ) <= iMaxConsolidate  ){ 
					vConsolidated.push_back(curr);
					iNumReads += curr.size();
					curr.clear();
				}
			}
			else{ //we have left subcluster in curr
				 //we have left_anchored subcluster: move it to prev_vector by inserting at end--in case prev_vector is not empty.
				  // ..... do so only if they intersect
				if( prev_vector.size()>0 ){
					if( !reads_intersect(prev_vector[prev_vector.size()-1], curr[0])){ //if they do not intersect, push prev_vector in candidate regions
						if((prev_vector.size()) >= iMinConsolidate && (prev_vector.size()) <= iMaxConsolidate  ){
								vConsolidated.push_back(prev_vector);
								iNumReads += prev_vector.size();
						}
						//clear in both cases
						prev_vector.clear();
					}
				 }
				prev_vector.insert(prev_vector.end(), curr.begin(), curr.end());
			}
			curr.clear(); 
			if(vCandidateReads[i].iChromosome == iChr+1 ) //increment only if we jumped to a new chromosome
			{       ++iChr; 
			cout << "\nChromsome: " << iChr << endl;
			if (bOnlyOneChr) // if the user only wants to cluster one chromosome, we break out here
				break;
			}
		}
        //////case 5: just add it to the cluster and update iLastEndLoc
		curr.push_back(vCandidateReads[i]);
		curr_left_anchored = left_anchored(vCandidateReads[i]);
		iLastEndLoc = vCandidateReads[i].iParentStart + vCandidateReads[i].sParentRead.length() - 1;
	}

	fLogFileOut << "Number clusters skipped: " << iSkippedCluster << endl;
	cout << "\nNumber reads after consolidation: " << iNumReads << endl;
	fLogFileOut << "Number reads after consolidation: " << iNumReads << endl;
	cout << "Number of clusters: " << vConsolidated.size() << endl;
	fLogFileOut << "Number of clusters: " << vConsolidated.size() << endl;

	// Now the program will print out the consolidate read locations
	// A MySQL and Perl script is required to parse the data to further the program
	// The program will now exit
	fLogFileOut << "\nPrinting half_read_clusters.txt" << endl;
	ofstream output;
	output.open((sProjectDirectory + sHalfReadClusters.c_str()).c_str());
	long long int size2 = 0;
	for (long long int i = 0; i < vConsolidated.size(); ++i){
		size2 = vConsolidated[i].size();
		for (long long int j = 0; j < size2; ++j){
			output << vConsolidated[i].at(j).sReadName << "\t" << vConsolidated[i].at(j).sParentRead << "\t" << vConsolidated[i].at(j).iParentStart << "\t" << vConsolidated[i].at(j).iChromosome << "\t"<< i << endl;
		}
	}
	output.close();

	// print out the half-read clustered locations
	/*fLogFileOut << "Printing half_read_clustered_locations.txt" << endl;
	output.open("half_read_clustered_locations.txt");
	output << "i\tchr\tsize\tmin\tmax\tlength" << endl;
	for (int i = 0; i < iNumReads; ++i){
		int min = 0;
		int max = 0;
		size2 = vConsolidated[i].size();
		for (int j = 0; j < size2; ++j){
			if (j == 0)
				min = vConsolidated[i].at(j).iParentStart;
			else if (vConsolidated[i].at(j).iParentStart < min)
				min = vConsolidated[i].at(j).iParentStart;
			if (max < vConsolidated[i].at(j).iParentEnd)
				max = vConsolidated[i].at(j).iParentEnd;
		}
		output << i << "\t" << vConsolidated[i].at(0).iChromosome << "\t" << size2 << "\t" << min << "\t" << max << "\t" << (max - min + 1) << endl;
	}
	output.close();*/

	fLogFileOut << "\nCluster time = " << (long long int)time(NULL)-time0 << endl;

	// clean up memory before exiting
	//cout << "\nCleaning vCandidateReads..." << endl;
	//vCandidateReads.clear();
	//cout << "Cleaning vConsolidated..." << endl;
	//vConsolidated.clear();

	//exit(0);
}

