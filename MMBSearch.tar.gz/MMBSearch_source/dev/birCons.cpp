
/// Case 1 & 2: 1) We jumped to next chromosome; 2) we reached max numer of reads in a cluster
//// in each case, we need to check if we already have enough reads to form a cluster or not; 
	/// if yes, write a new cluster, and start a fresh one; if not, erase previous candidate cluster due to insufficient reads, and a start a new one  
///// Case 3: we reached a disconnected region--no overlapping with previous cluster.
		if (vCandidateReads[i].iChromosome == iChr+1 || curr.size() == iMaxConsolidate || vCandidateReads[i].iParentStart > iLastEndLoc ){ 

			if (curr.size() >= iMinConsolidate && curr.size() <= iMaxConsolidate ){ 
				vConsolidated.push_back(curr);
				iNumReads += curr.size();
			} else {
				++iSkippedCluster;
			}
			curr.clear();
			
			if(vCandidateReads[i].iChromosome == iChr+1 ) //increment only if we jumped to a new chromosome
			{       ++iChr;
				cout << "\nChromsome: " << iChr << endl;
				if (bOnlyOneChr) // if the user only wants to cluster one chromosome, we break out here
				break;
			}
		}

//////case 4: just add it to the cluster
		curr.push_back(vCandidateReads[i]);
		iLastEndLoc = vCandidateReads[i].iParentStart + vCandidateReads[i].sParentRead.length() - 1;
	}
