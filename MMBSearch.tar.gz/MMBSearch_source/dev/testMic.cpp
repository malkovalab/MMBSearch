
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <sys/wait.h>
#include <stdlib.h>
#include <algorithm>
#include <limits.h>
#include <ctime>
#include <cmath>

using namespace std;



string getReverseComplement(string &str){
	string rev;

	for (unsigned int i = 0; i < str.length(); ++i){
		if (str[i] == 'A')
			rev = 'T' + rev;
		else if (str[i] == 'C')
			rev = 'G' + rev;
		else if (str[i] == 'G')
			rev = 'C' + rev;
		else if (str[i] == 'T')
			rev = 'A' + rev;
		else
			rev = 'N' + rev;
	}

	return rev;
}


void findMicHomology(string bir, string ref, string sAlignedRegionJ, string sAlignedRegionI , bool inverted)
{
	string insertion = sAlignedRegionJ;
	string Temp = sAlignedRegionI;
	string micHomInsertion;
	string micHomTemplate;
	//get reverse complement if inverted 
	//if(inverted){
		//insertion = getReverseComplement(insertion);
	//}
	cout<<"Insertion: "<<insertion<<endl;
	cout<<"template: "<<Temp<<endl;
	int posInsertion;
	int posTemplate;
	
	size_t found = bir.find(insertion); 
    if (found == string::npos){
    	//return "Insertion is not found\n";
    }
   // else 
   posInsertion = (int) found;
   cout<<" posInsertion is "<<posInsertion<<endl<<endl;
    
    found = ref.find(Temp);
    if(found == string::npos);
    	//return "Template is not found\n";
	else 
		posTemplate = (int) found;
	
	int leftCoordIns;
	int rightCoordIns;
	int leftCoordTemp;
	int rightCoordTemp;
	int preInsLength;
	int postInsLength;
	int preTempLength;
	
	int posInsPlusLength = posInsertion+insertion.size();
	int posTempPlusLength = posTemplate+Temp.size();
	
	//get the area where we have the microhomology
	if(posInsertion < posTemplate){
		//micHomMiddle = bir.substr(posInsertion+insertion.size(), posTemplate); //get from the end of the insertion to start of template 
		if(posInsertion > 8){
			//micHomLeftInsertion = bir.substr(posInsertion-8, 8);
			leftCoordIns = posInsertion-8;
			preInsLength = 8;
		}
		else{
			//micHomLeftInsertion = bir.substr(0, posInsertion); 
			leftCoordIns = 0;
			if(posInsertion > 0)
				preInsLength = posInsertion-1;
			else preInsLength =0;
		}
		if( (posTemplate -posInsPlusLength) > 16){
			//micHomRightInsertion = bir.substr(posInsertion+insertion.size() , 8 );
			rightCoordIns = preInsLength + insertion.size() + 8;
		}
		else{
			//micHomRightInsertion = bir.substr( (posInsertion+insertion.size()), (posTemplate - (posInsertion+insertion.size()))/2);
			rightCoordIns = preInsLength + insertion.size() + ((posTemplate - (posInsPlusLength))/2);
			
		}
		cout<<"DEBUGGING........ posInsertion < posTemplate:\n"; 
		cout<<"leftCoordIns: "<<leftCoordIns<<"  rightCoordIns: "<<rightCoordIns<<endl;
		micHomInsertion = bir.substr( leftCoordIns,  rightCoordIns-1);
		//cout<<"1- Left  and right insertions\n";
		
		if( posTemplate - posInsPlusLength > 16){
			//micHomLeftTemp = ref.substr(posTemplate - 8, 8);
			leftCoordTemp = posTemplate - 8;
			preTempLength = 8;
		}
		else{
		 	//micHomLeftTemp = ref.substr( posTemplate - (posTemplate - (posInsertion+insertion.size()))/2,  (posTemplate - (posInsertion+insertion.size()))/2);
			leftCoordTemp = posTemplate - ((posTemplate - posInsPlusLength)/2);
			preTempLength = (posTemplate - posInsPlusLength)/2;
			if(leftCoordTemp < 0){
				leftCoordTemp = 0;
				preTempLength = posTemplate-1;
				if(posTemplate == 0)
					preTempLength = 0; 
			}
		}
		if(ref.size() - posTemplate+Temp.size() >8 ){
			//micHomRightTemp = ref.substr(posTemplate+Temp.size(), 8);
			rightCoordTemp = preTempLength + Temp.size() + 8;
		}
		else{ 
			//micHomRightTemp = ref.substr(posTemplate+Temp.size());
			rightCoordTemp = ref.size() - leftCoordTemp; //+ preTempLength + Temp.size());
		}
		//cout<<"DEBUGGING........ posInsertion < posTemplate:\n"; 
		cout<<"leftCoordTemp: "<<leftCoordTemp<<"  rightCoordTemp: "<<rightCoordTemp<<endl;
		micHomTemplate = ref.substr(leftCoordTemp , rightCoordTemp-1);
		micHomTemplate = getReverseComplement(micHomTemplate );
		 
		//cout<<"1- Left  and right template\n";
	}
	else{
	
		if(posTemplate > 8){
			//micHomLeftInsertion = bir.substr(posInsertion-8, 8);
			leftCoordTemp = posTemplate-8;
			preTempLength = 8;
		}
		else{
			//micHomLeftInsertion = bir.substr(0, posInsertion); 
			leftCoordTemp = 0;
			preTempLength = posTemplate-1;  //Check if it is just posTemplate, without -1
			if(preTempLength < 0)
				preTempLength = 0;
		}
		
		if((posInsertion - posTempPlusLength) > 16){
			//micHomRightInsertion = bir.substr(posInsertion+insertion.size() , 8 );
			rightCoordTemp = preTempLength + Temp.size() + 8;
		}
		else{
			//micHomRightInsertion = bir.substr( (posInsertion+insertion.size()), (posTemplate - (posInsertion+insertion.size()))/2);
			rightCoordTemp = preTempLength + Temp.size() + ((posInsertion - posTempPlusLength)/2);
			
		}
		
		cout<<"DEBUGGING........ posInsertion > posTemplate:\n"; 
		cout<<"leftCoordTemp: "<<leftCoordTemp<<"  rightCoordTemp: "<<rightCoordTemp<<endl;
		micHomTemplate  = ref.substr( leftCoordTemp,  rightCoordTemp-1);
		micHomTemplate = getReverseComplement(micHomTemplate);
		//cout<<"1- Left  and right insertions\n";
		
		if( (posInsertion - posTempPlusLength) > 16){
			//micHomLeftTemp = ref.substr(posTemplate - 8, 8);
			cout<<"IN if( posInsertion - (posTemplate+Temp.size()) > 16){....." <<"\n";
			leftCoordIns = posInsertion - 8;
			preInsLength = 8;
		}
		else{
		cout<<"IN else of if( posInsertion - (posTemplate+Temp.size()) > 16){ ....\n";
		 	//micHomLeftTemp = ref.substr( posTemplate - (posTemplate - (posInsertion+insertion.size()))/2,  (posTemplate - (posInsertion+insertion.size()))/2);
			leftCoordIns = posInsertion - ((posInsertion - (posTempPlusLength))/2);
			preInsLength = (posInsertion - (posTempPlusLength))/2;
			if(leftCoordIns <0){
				cout<<"IN if(leftCoordIns <0){ ....\,";
				leftCoordIns = 0;
				preInsLength = posInsertion - 1;
				if(preInsLength <0)
					preInsLength = 0;
			}
		}
		if(bir.size() - posInsPlusLength >8 ){
			//micHomRightTemp = ref.substr(posTemplate+Temp.size(), 8);
			rightCoordIns = preInsLength + insertion.size() + 8;
		}
		else{ 
			//micHomRightTemp = ref.substr(posTemplate+Temp.size());
			rightCoordIns = bir.size() - leftCoordIns; 
		}
		
		//cout<<"DEBUGGING........ posInsertion < posTemplate:\n"; 
		cout<<"lefttCoordIns: "<<leftCoordIns<<"  rightCoordIns: "<<rightCoordIns<<endl;
	
		micHomInsertion = bir.substr(leftCoordIns , rightCoordIns-1);
		//cout<<"1- Left  and right template\n";
	}
	
	cout<< "Microhomology Insertion: "+micHomInsertion+"\n Microhomology template: "+micHomTemplate+"\n";
}



int main(){

string bir = "GGGAGAGGGAGAGGGAGAGGGAGAGGGAGAGGTCTCCCTCTCCCTCTCCCTCTCCCTCTCCCTCTCCCTCTCCCGTCTCCCGTCTCCCGTCTCCCGTCTCCCGTCTCCCGTCTCCCGTCTCCCGTC";
string ref = "CCTCTCCCTCTCCCTCTCCCTCTCCCTCTCCCTCTCCCTCTCCCTCTCCCTCTCCCTCTCCCTCTCCCTCTCCCGTCTCCCGTCTCCCGTCTCCCGTCTCCCGTCTCCCGTCTCCCGTCTCCCGTCTGCCG";
string ins = "GGAGAGGGAGAGGGAGAGGGAGAGGGAGAG";
string temp = "CTCTCCCTCTCCCTCTCCCTCTCCCTCTCC";

findMicHomology(bir,  ref, ins, temp , false);



return 0;
}