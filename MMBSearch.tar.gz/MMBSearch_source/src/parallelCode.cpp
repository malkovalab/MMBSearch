
#include "mpi.h"

//#include "defs.h"

#include <stdio.h>
#include<string>

#include<time.h>
#include <unistd.h>

#include <iostream>
#include <stdexcept>
#include <stdio.h>
#include <string>

#include <sstream>
#include <stdio.h>
#include<string>
#include <iostream>
#include <fstream>
#include <map>
#include <vector>
#include <sstream>
#include <sys/wait.h>
#include <stdlib.h>
#include <fstream>

#include <stdio.h>
#include <stdexcept>
#include<string.h>
#include <iostream>
#include <fstream>
#include <map>
#include <vector>
#include <sstream>
#include <sys/wait.h>
#include <stdlib.h>
#include <sstream>


#include <sstream>

using namespace std;

//string sBaseFileName;
string sProjectDirectory;
string sLogDirName;
ofstream fLogFileOut;
string sReferenceFile;
bool pairedEnd;
bool bamFile;
unsigned int iMinSeqLength;

/*
string setupBaseFileName()
{
    string sBaseFileName;
    char sTime[50];
    time_t t;
    tm *tmptr;

    t = time(NULL);
    tmptr = localtime(&t);
    strftime(sTime,50,"%Y%m%d_%H%M",tmptr);

    sBaseFileName = sTime;
    if (sJobId == "")
	sJobId = "0";

    sBaseFileName += "_" + sJobId + "_";

    cout << "BASE FILE NAME: " << sBaseFileName << endl;
    return sBaseFileName;
}

*/


void prepareLogFile(  )
{
#define DIRNAME_LEN 1024
    
    string sBaseFileName = "LogFile";

	char curwd[DIRNAME_LEN];
    // Get the current working directory
    if (getcwd(curwd, DIRNAME_LEN) == NULL)
	perror("getcwd error");

    string sFile = sLogDirName + "/" + sBaseFileName+"Parallel" + "Log.txt";

    // Turn on exceptions for file output stream
    fLogFileOut.exceptions(ios::failbit|ios::badbit);
    try {
	fLogFileOut.open(sFile.c_str());
    }
    catch (ios_base::failure& e) {
	throw ios_base::failure(string("Failed to open ") + sFile);
    }

    time_t t;
    t = time(NULL);
    fLogFileOut << "Log File Started: " << ctime(&t) << "\r\n";
    fLogFileOut << "Base File Name: " << sBaseFileName << "\r\n";
}



template <typename T>
  string NToString ( T Number )
  {
    ostringstream ss;
    ss << Number;
    return ss.str();
  }

int executeBwaIndex(string sReferenceFile,  int id){
	string command;

	// start BWA index
	cout << "\nstarting bwa index..." << endl;
	fLogFileOut << "\nstarting bwa index.....process: "<<id << endl;
	command = "./bwa index -a bwtsw " + sReferenceFile;
	system(command.c_str());
	cout << "bwa index finished..." << endl;
	fLogFileOut << "bwa index finished....... process: "<<id <<  endl;

	return 0;
}

int executeBwaAligner(string sReferenceFile, string sReadsFile, string sOutputFile, int t,  int id){

	string command;

	// run the BWA alignment algorithm
	cout << "\nstarting bwa aligner..." << endl;
	fLogFileOut << "\nstarting bwa aligner...process: "<<id << endl;
	
	//check if multi-threading is chosen
	if(t> 0){
	
	    command = "./bwa aln -n 4 -t "+NToString(t) +" "+ sReferenceFile + " "  + sProjectDirectory + sReadsFile +" | bwa samse " + sReferenceFile  +  " - " + sProjectDirectory + sReadsFile + " > " + sProjectDirectory +  sOutputFile + ".sam";	}
	else {
	    command = "./bwa aln -n 4 " + sReferenceFile + " " + sProjectDirectory  + sReadsFile +" | bwa samse " + sReferenceFile +  " - " + sProjectDirectory + sReadsFile+ " > " + sProjectDirectory +  sOutputFile + ".sam";
	}
	cout << "command: " << command << endl;
	system(command.c_str());
	cout << "bwa aligner finished..." << endl;
	fLogFileOut << "bwa aligner finished..." << endl;

	return 0;
}

//each process changes the name of the files it processes to facilitate merging them.
string processFileName(string s, int id){
    if (id <10)
	return (s+"000"+NToString(id));
    if (id <100)
	return (s+"00"+NToString(id));
    if (id <1000)
	return (s+"0"+NToString(id));

    return (s+NToString(id));
    
}





int getReads(string sUnalignedFile, string sBwaOutputFile, string sFlag1, string sFlag2, bool bFlagFirst){
	//bool bPairedEnd = confDB.getKey("pairedEnd").boolVal;
	string command;

	if (pairedEnd){
		cout << "\n** Paired-end functionality has not been implemented yet" << endl;
		exit(1);
	} else {
		if (bamFile == true && bFlagFirst == true)
			command = "samtools view -h " + sFlag1 + " " + sProjectDirectory + sBwaOutputFile + " > " + sProjectDirectory + sUnalignedFile  + "_flag_1.sam";
		else
			command = "samtools view -h " + sFlag1 + " -S " + sProjectDirectory + sBwaOutputFile + " > " + sProjectDirectory + sUnalignedFile  + "_flag_1.sam";

cout<<"........ passes first call of sametools\n";			
		// run samtools to get unaligned reads
		cout << "\nget samtools reads with flag " + sFlag1 + " into " << sProjectDirectory + sUnalignedFile << "_flag_1..." << endl;
		fLogFileOut << "\nget samtools reads with flag " + sFlag1 + " into " << sProjectDirectory + sUnalignedFile << "_flag_1..." << endl;
		system(command.c_str());

		if (sFlag2.compare("") != 0){
			command = "samtools view -h " + sFlag2 + " -S " + sProjectDirectory + sBwaOutputFile + " > " + sProjectDirectory + sUnalignedFile  + "_flag_2.sam";
			cout << "\nget samtools reads with flag " + sFlag2 + " into " << sProjectDirectory + sUnalignedFile << "_flag_2..." << endl;
			fLogFileOut << "get samtools reads with flag " + sFlag2 + " into " << sProjectDirectory + sUnalignedFile << "_flag_2..." << endl;
			system(command.c_str());

			// merge two files together
			cout << "\nmerging SAM files..." << endl;
			fLogFileOut << "merging SAM files..." << endl;
			command = "cat " + sProjectDirectory + sUnalignedFile + "_flag_1.sam > " + sProjectDirectory + sUnalignedFile + ".sam";
			system(command.c_str());

			command = "cat " + sProjectDirectory + sUnalignedFile + "_flag_2.sam | awk '$1 !~ /@/' >> " + sProjectDirectory + sUnalignedFile +  ".sam";
			system(command.c_str());

			// remove _flag files
			cout << "\nremoving _flag files..." << endl;
			fLogFileOut << "removing _flag files..." << endl;
			command = "rm *flag_*.sam";
			system(command.c_str());
		} else {
			// move _flag_1 to regular .sam file
			command = "mv " + sProjectDirectory + sUnalignedFile + "_flag_1.sam " + sProjectDirectory + sUnalignedFile + ".sam";
			system(command.c_str());
		}
	}
	return 0;
}

int convertSAMtoFASTA(string sUnalignedFile){
	string command = "";
	command = "samtools view -S " + sProjectDirectory + sUnalignedFile + ".sam | ";
	command += " awk '{OFS=\"\t\"; print \">\"$1\"-1\\n\"substr($10,1,length($10)/2)\"\\n>\"$1\"-2\\n\"substr($10,length( $10)/2+1,length($10))}' - > ";
	command += sProjectDirectory + sUnalignedFile + ".temp";

	cout << "\nConverting SAM to FASTA..." << endl;
	fLogFileOut << "\nConverting SAM to FASTA..." << endl;
	system(command.c_str());

	ifstream input;
	ofstream output;
	string line = sProjectDirectory + sUnalignedFile + ".temp";
	input.open(line.c_str());
	line = sProjectDirectory + sUnalignedFile + ".fasta";
	output.open(line.c_str());
	//int iLength = 0; // length of the nucleotide sequence
	//unsigned int iMinSeqLength = confDB.getKey("minSeqLength").intVal;
	int count = 1;
	int iTooShort = 0;
	string header = "";

	while (input.good()){
		getline(input, line);

		if (line[0] == '>'){
			header = line;
			++count;
			continue;
		}
		if (line.length() < iMinSeqLength && count == 2){
			getline(input, line);
			getline(input, line);
			count = 1;
			++iTooShort;
			continue;
		}
		output << header << endl;
		output << line << endl;
		++count;
		if (count == 5)
			count = 1;
	}
	cout << "filtered reads too short: " << iTooShort << endl;
	fLogFileOut << "filtered reads too short: " << iTooShort << endl;
	cout << "finished..." << endl;
	input.close();
	output.close();

	command = "rm " + sProjectDirectory + sUnalignedFile + ".temp";
	system(command.c_str());
	return 0;
}

int filterOut (string sOutputFile, string sInputFile, string sFlag1, string sFlag2){
	string command;
	cout << "\nfiltering " + sFlag1 + " out of " + sProjectDirectory + sInputFile + " into " + sProjectDirectory + sOutputFile + ".temp..." << endl;
	fLogFileOut << "\nfiltering " + sFlag1 + " out of " + sProjectDirectory + sInputFile + " into " + sProjectDirectory + sOutputFile + ".temp..." << endl;
	command = "samtools view -h " + sFlag1 + " -S " + sProjectDirectory + sInputFile + ".sam > " + sProjectDirectory + sOutputFile + ".temp";
	system(command.c_str());

	if (sFlag2.compare("") != 0){
		cout << "filtering " + sFlag2 + " out of " + sProjectDirectory + sInputFile + " into " + sProjectDirectory + sOutputFile + ".sam..." << endl;
		
		fLogFileOut << "filtering " + sFlag2 + " out of " + sProjectDirectory + sInputFile + " into " +sProjectDirectory +  sOutputFile +  ".sam..." << endl;
		command = "samtools view -h " + sFlag2 + " -S " + sProjectDirectory + sOutputFile + ".temp > " + sProjectDirectory + sOutputFile +  ".sam";
		system(command.c_str());

		cout << "\ncleaning up..." << endl;
		fLogFileOut << "cleaning up..." << endl;
		command = "rm " + sProjectDirectory + sOutputFile + ".temp";
		system(command.c_str());
	} else {
		// move _temp to regular .sam file
		command = "mv " + sProjectDirectory + sOutputFile + ".temp " + sProjectDirectory + sOutputFile + ".sam";
		system(command.c_str());
	}
	return 0;
}






/// #############################################################
//////################## main #####################################

int main ( int argc, char *argv[] )

{
  int id;
  int ierr;
  int p;
  double wtime;
  
//
//  Initialize MPI.
//
  ierr = MPI_Init ( &argc, &argv );
//
//  Get the number of processes.
//
  ierr = MPI_Comm_size ( MPI_COMM_WORLD, &p );
//
//  Get the individual process ID.
//
  ierr = MPI_Comm_rank ( MPI_COMM_WORLD, &id );
//
  
//############# First get the name of config filet
  
  string confFile = argv[1];
  
  cout<<confFile<<endl;
  
  int t=0;
  ///Open the conf file

    string line; // line reading in
	ifstream input;
	input.open(confFile.c_str());



///process the lines one by one
while (input.good()){
    getline(input, line);    
  istringstream iss(line);
  
  string sub;
  iss>>sub;
  string temp;
  
  if(sub.compare("-1") == 0){
    string pe;
    string bf;
    string msl;
    string pd;
    string sld;
    string rf;
    
    iss>>pe;
    iss>>bf;
    iss>>msl;
    iss>>pd;
    iss>>sld;
    iss>>rf;
    
    if(pe.compare("true") == 0)
	pairedEnd = true;
    else pairedEnd = false;
    
    if(bf.compare("true") == 0)
	bamFile = true;
    else bamFile = false;
    
    iMinSeqLength = atoi(msl.c_str());   
	
    sProjectDirectory = pd;
    
    sLogDirName = sld;
    
    sReferenceFile = rf;
    
    
    
    
      
  }
  else if(sub.compare("0") == 0){
      string s;
      iss>>s;
      
      t = atoi(s.c_str());
      
  }
  else if(sub.compare("1") == 0){
      if(id == 0){
	string sReferenceFile;
      iss>> sReferenceFile; //reference file
      if (executeBwaIndex(sReferenceFile,  id) != 0)
	  cout << "BWA index exited incorrectly" << endl;
      }
  }
  else if(sub.compare("2") == 0){
      string srf;
string pdir;
      string sr;
    string sof;
    string tail;
    iss>>srf;
iss>>pdir;
      iss>>  sr;
    iss>>sof;
    iss>>tail;
    
    //append the id of the node to the end of the reads and output files.
    string sReferenceFile = srf;
    string splittedReads = processFileName(sr, id+1);
    string sOutputFile = processFileName(sof, id+1);
          cout<<"DEBUGGING PARALLEL process "<< id<<"  Before aligning\n";
    string command = "mv "+pdir+splittedReads+" "+pdir+splittedReads+".fastq";
    //system(command.c_str());
    //////// note t is in the call

      if (executeBwaAligner(sReferenceFile, (splittedReads+".fastq"), (sOutputFile+tail),  t,  id)  != 0)
				cout << "BWA aligner 1 exited incorrectly" << endl;
				
	          cout<<"DEBUGGING PARALLEL process "<< id<<"  AFTER executing aligner \n";
      
  }
  else if(sub.compare("3") == 0){
      
      string suf;
      string tail;
      string sof;
    
      iss>>  suf;
      iss>>tail;
    iss>>sof;
    
    //append the id of the node to the end of the reads and output files.
    string sUnalignedFile = processFileName(suf,id);
    string sOutputFile = processFileName(sof, id);
      
      
      if (getReads((sUnalignedFile+tail) , (sOutputFile+tail + ".sam"), "-f 4", "", true) != 0)
				cout << "getReads 1 exited incorrectly" << endl;
  }
  else if(sub.compare("4") == 0){
      
      string suf;
      string saf;
    
      iss>>  suf;
    iss>>saf;
    
    //append the id of the node to the end of the reads and output files.
    string sUnalignedFile = processFileName(suf,id);
    string sAlignedFile = processFileName(saf, id);
      
      if (getReads(sUnalignedFile , (sAlignedFile), "-f 4", "", true) != 0)    	
cout << "getReads 1 exited incorrectly" << endl;
  }
  else if(sub.compare("5") == 0){
      string saf;
      string tail;
      iss>>saf;
      iss>>tail;
      string sUnalignedFile = processFileName(saf, id);
      
    if (convertSAMtoFASTA(sUnalignedFile+tail) != 0) 
	cout << "convertSAMtoFASTA 1 exited incorrectly" << endl;
  }
  else if(sub.compare("6") == 0){
	string srf;
      string suf;
      string tail1;
    string sof;
    string tail2;
    
    iss>>srf;
      iss>>  suf;
      iss>>tail1;
    iss>>sof;
    iss>>tail2;
    
    //append the id of the node to the end of the reads and output files.
    string sReferenceFile = srf;
    string sUnalignedFile = processFileName(suf, id);
    string sOutputFile = processFileName(sof, id);
      
      if (executeBwaAligner(sReferenceFile,(sUnalignedFile+tail1+".fasta"), (sOutputFile+tail2),  t,  id) != 0)
		    cout << "BWA aligner 2 exited incorrectly" << endl;
  }
  else if(sub.compare("7") == 0){
      
      string suf;
      string tail1;
      string sof;
      string tail2;
      
      iss>>suf;
      iss>>tail1;
      iss>>sof;
      iss>>tail2;
      
      string sUnalignedFile = processFileName(suf, id);
      string sOutputFile = processFileName(sof, id);
      
      
 if (getReads((sUnalignedFile+tail1 ), (sOutputFile +tail2+ ".sam"), "-f 4", "", 
false) != 0)
	  cout << "getReads 2 exited incorrectly" << endl;
      
      
  }
  
  else if(sub.compare("8") == 0){
    string faf;
    string of;
    string tail;
    
    iss>>faf;
    iss>>of;
    iss>>tail;
    
    string sFinalAlignedFile = processFileName(faf, id);
    string sOutputFile = processFileName(of, id);
    
    if (filterOut((sFinalAlignedFile), (sOutputFile + tail), "-F 4", "")!= 0)
               cout << "Filter out exited incorrectly" << endl;

    
  }
  	

}


input.close();

  MPI_Finalize ( );




//cout<<"Processsssssssss after finalize: "<<id;


///////////Files merging
input.open(confFile.c_str());






input.close();


//
//  Termininate.
//

  
  
  return 0;
}




