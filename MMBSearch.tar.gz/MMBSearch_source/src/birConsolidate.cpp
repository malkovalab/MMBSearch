/*
 * birConsolidate.cpp
 *
 *  Created on: Apr 16, 2013
 *      Author: msegar
 */


#include "defs.h"

#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <vector>
#include <sstream>
#include <sys/wait.h>
#include <stdlib.h>
#include <algorithm>
#include <limits.h>
#include <ctime>
#include <cmath>
#include <map>
#include <iomanip>
#include<map>

using namespace std;

// birConsolidate
int startConsolidate(){
cout << "\nstartConsolidate start..." << endl;
fLogFileOut << "\nstartConsolidate start..." << endl;
ofstream output;

// only perform clustering if user option is specified
if (confDB.getKey("performClustering").boolVal == true){
	cout << "start candidate read sorting..." << endl;
	fLogFileOut << "start candidate read sorting..." << endl;
	
	fLogFileOut << "Before consolidation: " << vCandidateReads.size() << endl;
	cout << "Printing unconsolidated_bir_locations.txt..." << endl;
	output.open((sProjectDirectory + "unconsolidated_bir_locations.txt").c_str());
	for (long long int i = 0; i < vCandidateReads.size(); ++i){
		if (vCandidateReads[i].bBadRead)
			continue;
		output << vCandidateReads[i].iChromosome << ", " << vCandidateReads[i].iParentStart << "," << vCandidateReads[i].iParentEnd << endl;
	}
	output.close();


	createParentReads();

	// sort the parent starting locations for each chromosome from smallest to largest
	sort(vCandidateReads.begin(), vCandidateReads.end(), compareStart);
	// Finally, let's consolidated the possible BIR locations to speed up the alignment steps. This is based on overlapping regions
	consolidateLocations();

	fLogFileOut << "\nAfter consolidation: " << vConsolidated.size() << endl;

	if (confDB.getKey("mysql").boolVal){
		vCandidateReads.clear();
		//vConsolidated.clear();
		exit(0);
	}
}

// Let's destruct all the elements in the database to save space
vCandidateReads.clear();
//vConsolidated.clear();

/*
 * *************************************************************************************************************************
 * ******************			THIS IS WHERE THE PROGRAM SPLITS IN TWO. PREVIOUS TO THIS POINT,          ******************
 * ******************           THE PROGRAM WORKS AS SPECIFIED. THE PROGRAM NOW REQUIRES ANOTHER          ******************
 * ******************           SCRIPT THAT UTILIZES MYSQL TO SEARCH FOR THE HALF-READS QUICKLY.          ******************
 * ******************          THE PROGRAM NOW WILL IMPORT THE RESULTS FROM THE SCRIPT AND CONTINUE.      ******************
 * *************************************************************************************************************************
 */
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /*  Merge clusters here AFTER making the parent reads, to make it easier to find disconnected clusters so they are not merged if so.   */
       
       //mergeClusters();
       
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Make all the reads in a cluster the same length
getConsensus();

// Add the step to help classify each cluster before making consensus reads
//int aBase[1000], uaBase[1000], dBase[1000];
	//int types[vConsolidated.size()];
	
	
	ofstream outputCluster;
	outputCluster.open((sProjectDirectory + "clustered_locations2.txt").c_str());
	outputCluster << "i\tj\tstart\tchr\tread" << endl;
	/*
	for(int i=0; i<vConsolidated.size(); i++){
		types[i] = clusterClass(i, 0.8);
	}
	*/
	
	for(int i=0; i<vConsolidated.size(); i++){
		/////////////////print to cluster files
		for ( int j = 0; j < vConsolidated[i].size(); ++j){
					
			//output << i << ", " << j << ", " << vConsolidated[i].at(j).iParentStart << ", " << vConsolidated[i].at(j).iChromosome << ", " << vConsolidated[i].at(j).sParentRead << endl;
					if(vConsolidated[i][j].bAnchorLeft == true && vConsolidated[i][j].iFlag != 16){
						outputCluster << i << ", " << j << ", " << vConsolidated[i].at(j).iParentStart << ", " << vConsolidated[i].at(j).iChromosome <<", LEFTT Anch"<< ", " << vConsolidated[i].at(j).sParentRead <<endl;
					}else if(vConsolidated[i][j].bAnchorLeft == true && vConsolidated[i][j].iFlag == 16){
							vConsolidated[i][j].bAnchorLeft = false; // This is to get rid of this check condition every time 
						outputCluster << i << ", " << j << ", " << vConsolidated[i].at(j).iParentStart << ", " << vConsolidated[i].at(j).iChromosome <<", RIGHT Anch"<< ", " << vConsolidated[i].at(j).sParentRead <<endl;
					}else if (vConsolidated[i][j].bAnchorLeft == false && vConsolidated[i][j].iFlag != 16){
						outputCluster << i << ", " << j << ", " << vConsolidated[i].at(j).iParentStart << ", " << vConsolidated[i].at(j).iChromosome <<", RIGHT Anch"<< ", " << vConsolidated[i].at(j).sParentRead <<endl;
					}else{
						outputCluster << i << ", " << j << ", " << vConsolidated[i].at(j).iParentStart << ", " << vConsolidated[i].at(j).iChromosome <<", LEFTT Anch"<< ", " << vConsolidated[i].at(j).sParentRead <<endl;
						vConsolidated[i][j].bAnchorLeft = true; // This is to get rid of this check condition every time 
					}
		}
		
		/*
		if(types[i]==1){
			vConsolidated[i][0].type = 1;
			outputCluster<<"type: Regular"<<endl;
		}
		else if(types[i]==2){
					vConsolidated[i][0].type = 2;
		 outputCluster<<"type: Non-regular"<<endl;
		 }
		else{ vConsolidated[i][0].type = 3;
		outputCluster<<"type: undecided!"<<endl;
		}
		*/
		/////////////END of cluster printing
	}
	//close half read clusters 
	outputCluster.close();

	// Create a consensus read that takes into consideration all the base calls at a specific location
	consolidateBaseCalls();


	// Let's destruct all the elements in the database to save space
	vConsolidated.clear();
	
	/////////NEW modeification //////////////////
	/*  add a step tp align the consensus reads of two consecutive clusters, and update the position of the right cluster
	    if there is a "squish" 
	 */
	 
	 //alignConsensusMerge(); 

	fLogFileOut << "\nConsolidation time = " << (int)time(NULL)-time0 << endl;

	output.open((sProjectDirectory+ "consolidated_bir_locations.txt").c_str());
	for (long long int i = 0; i < vCandidateRegions.size(); ++i){
		output << vCandidateRegions[i].iChromosome << ", " << vCandidateRegions[i].iParentStart << "," << vCandidateRegions[i].iParentEnd<< endl;
	}
		
///////////////////
	output.close();

	return 0;
}

/*
 * left_anchored():
 * return true if left anchored, false otherwise
*/

bool left_anchored(t_consolidated &read){

	if(read.bAnchorLeft == true && read.iFlag != 16){
			return true;
	}else if(read.bAnchorLeft == true && read.iFlag == 16){
			return false;
	}else if (read.bAnchorLeft == false && read.iFlag != 16){
			return false;
	}else{
			return true;
	}
}


//two t_consolidated reads intersect or not
bool reads_intersect(t_consolidated& left, t_consolidated& right){

	if(left.iParentStart+left.sParentRead.size()-1 > right.iParentStart)
		return true;
	else return false;
}


/*
 * ************************************************************
 * consolidateLocations
 *
 * This function takes all the candidate regions and groups them together by the starting location of the unaligned read. If
 * there is any overlap between the reads, then they will be grouped together.
 *
 * A config.txt parameter (minConsolidate) determines how many reads need to be used to consolidate.
 */
void consolidateLocations(){
	cout << "\nConsolidating read locations start..." << endl;
	fLogFileOut << "\nConsolidating read locations start..." << endl;

	// TODO Find better way to consolidate, maybe based on stdev and discard ones that aren't (ie through out outliers)
	long long int iLastEndLoc = 0;
	 long long int iMinConsolidate = confDB.getKey("minConsolidate").intVal; // the minimum number of reads to consolidate, otherwise don't add to vector
long long int iMaxConsolidate = confDB.getKey("maxConsolidate").intVal; // the max number of reads to consolidate in a single cluster
	vector<t_consolidated> curr;
	long long int iNumReads = 0;
	long long int iSkippedCluster = 0;

	long long int iChr = (confDB.getKey("chromosome").intVal == 0 ? 0 : confDB.getKey("chromosome").intVal - 1); // get the user specified chromoome
	bool bOnlyOneChr = (confDB.getKey("chromosome").intVal != 0 ? true :false);
	long long int sizeCan = vCandidateReads.size();
	long long int fivePercent = sizeCan / 20;
	string sHalfReadClusters = confDB.getKey("clusterFile").stringVal;
	
	/* new initializations for the new clustering scheme: cluster based on anchor side instead of intersection only*/
	bool first = true;
	bool curr_left_anchored = true; 
	bool prev_left_anchored = true;
	vector<t_consolidated> merged; //to merge subclusters when needed
	 bool prevLeftAnch ;
	 bool currLeftAnch;
	 bool prevLeftAnchLast;
	 int combinedSize;
	 int singleSize;
	//Make a new vector to save subclusters
	cout << "Chromsome: " << iChr << endl;
	
	///NOTE: we start after the first, where the first is put in merged
	//merged.insert(merged.end(), curr.begin(), curr.end() );
	curr_left_anchored = left_anchored(vCandidateReads[0]);
	for (long long int i = 1; i < sizeCan; ++i){ ///NOTE: we start after the first, where the first is put in merged
		if (i % fivePercent == 0)
			cout << "\tcandidateRead: " << i << " of " << sizeCan << " on chromosome " << iChr << " (" << ((i * 100) / sizeCan) << "%)" << endl;
		if (vCandidateReads[i].iChromosome < iChr)
			continue;
		/******************************************
						CASES
		/******************************************/ 
		/// Case 1 & 2: 1) We jumped to next chromosome;
		/////////////// 2) we reached max number of reads in a cluster
		//// in each case, we need to check if we already have enough reads to form a cluster or not; 
		/// if yes, write a new cluster, and start a fresh one; if not, erase previous candidate cluster due to insufficient reads, and a start a new one  
		///// Case 3: we reached a disconnected region--no overlapping with previous cluster.
		/////Case 4: We reached a read anchored opposite to the previous read (subcluster).
		if (vCandidateReads[i].iChromosome == iChr+1 || curr.size() == iMaxConsolidate || vCandidateReads[i].iParentStart > iLastEndLoc || curr_left_anchored != left_anchored(vCandidateReads[i]) ){ 
			
			if(vCandidateReads[i].iChromosome == iChr+1)
				iChr++;
			//we use subcluster iff its size is larger than 2 (maybe needs to be changed to 3
			if(curr.size()>2 && merged.size()==0){ /////IMPORTANT: if merged is previously empty, then we just save current subcluster and iterate
				merged.insert(merged.end(), curr.begin(), curr.end() );
			}
			else if(curr.size()>2 && merged.size()>0){
			
				currLeftAnch = left_anchored(curr[0]);
				prevLeftAnch = left_anchored(merged[0]);
				prevLeftAnchLast = left_anchored(merged[merged.size()-1]); //The anchored side of the last read
				combinedSize = merged.size() + curr.size();
				singleSize = merged.size(); //we only save the previous
			
				if(!(reads_intersect(merged[merged.size()-1], curr[0]) ) ){
					if(singleSize >= iMinConsolidate && singleSize <= iMaxConsolidate ){
						vConsolidated.push_back(merged);
					}
					merged.clear();
					merged.insert(merged.end(), curr.begin(), curr.end() );
				}
				else { //intersect
					
					if(prevLeftAnch == true &&  prevLeftAnchLast == true){ //only left, and since it intersect curr, merge even if current is right anchored
						merged.insert(merged.end(), curr.begin(), curr.end() );
					}
					else { //it consists of two subclusters: left and right, OR, just one right subcluster 
						if(currLeftAnch == false){ //current is right, and since they intersect, and the last read in previous is right anyway, merge
							merged.insert(merged.end(), curr.begin(), curr.end() );
						}
						else{ //current is left, so go ahead and push it in case it is enough as a cluster; then clear it and initialize merged with current.
							if(singleSize >= iMinConsolidate && singleSize <= iMaxConsolidate ){
								vConsolidated.push_back(merged);
							}
							merged.clear();
							merged.insert(merged.end(), curr.begin(), curr.end() );
						}
					}
					
				}//End of else for intersect
			
			}//End of if sattement if(curr.size()>2)
			///////// End of code checking for merging or adding and so
			curr.clear();
			curr.push_back(vCandidateReads[i]);
			curr_left_anchored = left_anchored(vCandidateReads[i]);
			iLastEndLoc = vCandidateReads[i].iParentStart + vCandidateReads[i].sParentRead.length() - 1;		
		}
		else{
			curr.push_back(vCandidateReads[i]);
			iLastEndLoc = vCandidateReads[i].iParentStart + vCandidateReads[i].sParentRead.length() - 1;
		}
	} //End of first for loop to consolidate subclusters of the same anchored direction in vConsTemp
			
	

	fLogFileOut << "Number clusters skipped: " << iSkippedCluster << endl;
	cout << "\nNumber reads after consolidation: " << iNumReads << endl;
	fLogFileOut << "Number reads after consolidation: " << iNumReads << endl;
	cout << "Number of clusters: " << vConsolidated.size() << endl;
	fLogFileOut << "Number of clusters: " << vConsolidated.size() << endl;

	// Now the program will print out the consolidate read locations
	// A MySQL and Perl script is required to parse the data to further the program
	// The program will now exit
	fLogFileOut << "\nPrinting half_read_clusters.txt" << endl;
	ofstream output;
	output.open((sProjectDirectory + sHalfReadClusters.c_str()).c_str());
	long long int size2 = 0;
	for (long long int i = 0; i < vConsolidated.size(); ++i){
		size2 = vConsolidated[i].size();
		for (long long int j = 0; j < size2; ++j){
			output << vConsolidated[i].at(j).sReadName << "\t" << vConsolidated[i].at(j).sParentRead << "\t" << vConsolidated[i].at(j).iParentStart << "\t" << vConsolidated[i].at(j).iChromosome << "\t"<< i << endl;
		}
	}
	output.close();
	fLogFileOut << "\nCluster time = " << (long long int)time(NULL)-time0 << endl;

}



//This version of createparentreads simply reads the preprocessed files and match directly by line number, not by map
int createParentReads(){
cout << "\nCreating parent reads start... " << endl;
	fLogFileOut << "\nCreating parent reads start... " << endl;

	string sUnalignedFile = confDB.getKey("unalignedFile").stringVal + "_2.sam"; // the name of the unaligned FASTA/SAM file
	//map<string, string> mUnaligned;
	//map<string, string>::iterator iter;
	string mUnaligned="";
	string iter="";

	ifstream input;
	input.open((sProjectDirectory + sUnalignedFile).c_str());
	vector<string> curr; // temporary vector to hold SAM file line
	// read in unaligned file, and skip over lines starting with @
	long long int index=0;
	string row;
	for ( row; getline(input, row, '\n');){
		if (row[0] == '@') // skip lines that start with '@'
			continue;
		else break;
	}

	cout << "Number of unaligned reads in " << sUnalignedFile << ": " << mUnaligned.size() << endl;
	fLogFileOut << "Number of unaligned reads in " << sUnalignedFile << ": " << mUnaligned.size() << endl;

	string sReadName = "";
	string sTemp = "";

	// Now loop through vCanidateReads appending unaligned info to the parent read

	long long int iFound = 0;
	//long long int iSize = vConsolidated.size();
	long long int iSize = vCandidateReads.size();
	long long int iSize2 = 0;
	char last;
	string unalignedHalf;
	
	vector<t_consolidated>& temp = vCandidateReads;////temp now is another name to vCandidateReads
	
	for (long long int i = 0; i < iSize; ++i){
		//vector<t_consolidated>& temp = vConsolidated[i];
		
		///////row contains the last read line from unaligned.
		/////    split into tokens to get the half read to append/concatenate to its parent read
		curr.clear();
		istringstream ss(row);
		for (string word; getline(ss, word, '\t');){
			curr.push_back(word);
		}
		unalignedHalf = curr[9]; // remove last 2 characters from read name

		//iSize2 = temp.size();
		if (i % 100000 == 0)
			cout << "MATCHING parent data....: " << i << endl;
		
		//for (long long int j = 0; j < iSize2; ++j){
			sReadName = temp[i].sReadName;
			//sReadName = vConsolidated[i].at(j).sReadName;
			last = sReadName[sReadName.size() - 1];
			sReadName.erase(sReadName.size() - 2); // remove last 2 characters

			//iter = mUnaligned.find(sReadName);
			//if (iter != mUnaligned.end()){
			
			//reverse-complement the unaligned half read if the aligned half is reversed (flag = 16)

				
				if(temp[i].iFlag == 16) //it is reverse complement
					unalignedHalf = getReverseComplement(unalignedHalf);
			
				if (last == '1'){
					if(temp[i].iFlag != 16)
						temp[i].sParentRead += unalignedHalf;
					else {
					temp[i].sParentRead = unalignedHalf + temp[i].sParentRead;
					//iparent start was not updated after retrieving the parent read.
					temp[i].iParentStartOriginal = temp[i].iParentStart; //This is need to save positions for comparisons with results before adjusting the read positions.
					temp[i].iParentStart = temp[i].iParentStart - unalignedHalf.size();
					}
				} else {
					if(temp[i].iFlag != 16)
					{
					temp[i].sParentRead = unalignedHalf + temp[i].sParentRead;
					
					//iparent start was not updated after retrieving the parent read.
					temp[i].iParentStart = temp[i].iParentStart - unalignedHalf.size();
					}
					
					else{ 
						temp[i].sParentRead += unalignedHalf;
					}
				}
				
				
				++iFound;
			//}
		////if we reach the end of vCandidateReads, break the 
		///   loop so getline does not fail on unaligned because end of file reached.
		if(i == iSize-1)
			break;
		//Get next read from unaligned file
		getline(input, row, '\n');
	}
	
	input.close();

	fLogFileOut << "Found parent reads: " << iFound << endl;


//////// Move this code to after the clustering step..
/*
	ofstream output;
	output.open((sProjectDirectory+ "clustered_locations.txt").c_str());

	output << "i\tj\tstart\tchr\tread" << endl;
	long long int size = vCandidateReads.size();
	//long long int size2 = 0;
	for (long long int i = 0; i < size; ++i) {
		//size2 = vConsolidated[i].size();
		//for (long long int j = 0; j < size; ++j)
			output << i << ", " << vCandidateReads[i].iParentStart << ", " << vCandidateReads[i].iChromosome << ", " << vCandidateReads[i].sParentRead << endl;
	}

	output.close();
	*/

	return 0;
	
}
// use this version of createparentreads if we cal it before clustering. Use the 
//  next, commented one, if we call it after clustering
/*
int createParentReads(){
	cout << "\nCreating parent reads start... " << endl;
	fLogFileOut << "\nCreating parent reads start... " << endl;

	string sUnalignedFile = confDB.getKey("unalignedFile").stringVal + "_2.sam"; // the name of the unaligned FASTA/SAM file
	map<string, string> mUnaligned;
	map<string, string>::iterator iter;

	ifstream input;
	input.open((sProjectDirectory + sUnalignedFile).c_str());
	vector<string> curr; // temporary vector to hold SAM file line


	
	// read in unaligned file
	long long int index=0;
for (string row; getline(input, row, '\n');){
		if (index % 10000000 == 0)
			cout << "REDING unaligned data....: " << index << endl;
		index++;

		if (row[0] == '@') // skip lines that start with '@'
			continue;
		curr.clear();
		istringstream ss(row);
		for (string word; getline(ss, word, '\t');){
			curr.push_back(word);
		}

		mUnaligned[curr[0].erase(curr[0].size() - 2)] = curr[9]; // remove last 2 characters from read name
	}
	input.close();

	cout << "Number of unaligned reads in " << sUnalignedFile << ": " << mUnaligned.size() << endl;
	fLogFileOut << "Number of unaligned reads in " << sUnalignedFile << ": " << mUnaligned.size() << endl;

	string sReadName = "";
	string sTemp = "";

	// Now loop through vCanidateReads appending unaligned info to the parent read

	//vector<t_consolidated>& temp;

	long long int iFound = 0;
	//long long int iSize = vConsolidated.size();
	long long int iSize = vCandidateReads.size();
	long long int iSize2 = 0;
	char last;
	string unalignedHalf;
	
	vector<t_consolidated>& temp = vCandidateReads;
	for (long long int i = 0; i < iSize; ++i){
		//vector<t_consolidated>& temp = vConsolidated[i];

		//iSize2 = temp.size();
		if (i % 100000 == 0)
			cout << "MATCHING parent data....: " << i << endl;
		
		//for (long long int j = 0; j < iSize2; ++j){
			sReadName = temp[i].sReadName;
			//sReadName = vConsolidated[i].at(j).sReadName;
			last = sReadName[sReadName.size() - 1];
			sReadName.erase(sReadName.size() - 2); // remove last 2 characters

			iter = mUnaligned.find(sReadName);
			if (iter != mUnaligned.end()){
			
			//reverse-complement the unaligned half read if the aligned half is reversed (flag = 16)
				unalignedHalf = iter->second;
				
				if(temp[i].iFlag == 16) //it is reverse complement
					unalignedHalf = getReverseComplement(unalignedHalf);
			
				if (last == '1'){
					if(temp[i].iFlag != 16)
						temp[i].sParentRead += unalignedHalf;
					else {
					temp[i].sParentRead = unalignedHalf + temp[i].sParentRead;
					//iparent start was not updated after retrieving the parent read.
					temp[i].iParentStart = temp[i].iParentStart - unalignedHalf.size();
					}
				} else {
					if(temp[i].iFlag != 16)
					{
					temp[i].sParentRead = unalignedHalf + temp[i].sParentRead;
					
					//iparent start was not updated after retrieving the parent read.
					temp[i].iParentStart = temp[i].iParentStart - unalignedHalf.size();
					}
					
					else{ 
						temp[i].sParentRead += unalignedHalf;
					}
				}
				
				
				++iFound;
			}
		
	}

	fLogFileOut << "Found parent reads: " << iFound << endl;


//////// Move this code to after the clustering step..


	return 0;
}
*/



/*
// use this version of createparentreads if we call it AFTER clustering. Use the 
//  previous, commented one, if we call it before clustering

int createParentReads(){
	cout << "\nCreating parent reads start... " << endl;
	fLogFileOut << "\nCreating parent reads start... " << endl;

	string sUnalignedFile = confDB.getKey("unalignedFile").stringVal + "_2.sam"; // the name of the unaligned FASTA/SAM file
	map<string, string> mUnaligned;
	map<string, string>::iterator iter;

	ifstream input;
	input.open((sProjectDirectory + sUnalignedFile).c_str());
	vector<string> curr; // temporary vector to hold SAM file line


	
	// read in unaligned file
	long long int index=0;
for (string row; getline(input, row, '\n');){
		if (index % 10000000 == 0)
			cout << "REDING unaligned data....: " << index << endl;
		index++;

		if (row[0] == '@') // skip lines that start with '@'
			continue;
		curr.clear();
		istringstream ss(row);
		for (string word; getline(ss, word, '\t');){
			curr.push_back(word);
			
		}

		mUnaligned[curr[0].erase(curr[0].size() - 2)] = curr[9]; // remove last 2 characters from read name
	}
	input.close();

	cout << "Number of unaligned reads in " << sUnalignedFile << ": " << mUnaligned.size() << endl;
	fLogFileOut << "Number of unaligned reads in " << sUnalignedFile << ": " << mUnaligned.size() << endl;

	string sReadName = "";
	string sTemp = "";

	// Now loop through vCanidateReads appending unaligned info to the parent read

	//vector<t_consolidated>& temp;

	long long int iFound = 0;
	long long int iSize = vConsolidated.size();
	long long int iSize2 = 0;
	char last;
	string unalignedHalf;
	
	for (long long int i = 0; i < iSize; ++i){
		vector<t_consolidated>& temp = vConsolidated[i];
		iSize2 = temp.size();
		if (i % 100000 == 0)
			cout << "MATCHING parent data....: " << i << endl;
		
		for (long long int j = 0; j < iSize2; ++j){
			sReadName = temp[j].sReadName;
			//sReadName = vConsolidated[i].at(j).sReadName;
			
			
			last = sReadName[sReadName.size() - 1];
			sReadName.erase(sReadName.size() - 2); // remove last 2 characters

			iter = mUnaligned.find(sReadName);
			if (iter != mUnaligned.end()){
			
			//reverse-complement the unaligned half read if the aligned half is reversed (flag = 16)
				unalignedHalf = iter->second;
				
				if(temp[j].iFlag == 16) //it is reverse complement
					unalignedHalf = getReverseComplement(unalignedHalf);
			
				if (last == '1'){
					if(temp[j].iFlag != 16)
						temp[j].sParentRead += unalignedHalf;
					else {
					temp[j].sParentRead = unalignedHalf + temp[j].sParentRead;
					//iparent start was not updated after retrieving the parent read.
					temp[j].iParentStart = temp[j].iParentStart - unalignedHalf.size();
					}
				} else {
					if(temp[j].iFlag != 16)
					{
					temp[j].sParentRead = unalignedHalf + temp[j].sParentRead;
					
					//iparent start was not updated after retrieving the parent read.
					temp[j].iParentStart = temp[j].iParentStart - unalignedHalf.size();
					}
					
					else{ 
						temp[j].sParentRead += unalignedHalf;
					}
				}
				
				
				++iFound;
			}
		}
	}

	fLogFileOut << "Found parent reads: " << iFound << endl;


	ofstream output;
	output.open((sProjectDirectory+ "clustered_locations.txt").c_str());

	output << "i\tj\tstart\tchr\tread" << endl;
	long long int size = vConsolidated.size();
	long long int size2 = 0;
	for (long long int i = 0; i < size; ++i) {
		size2 = vConsolidated[i].size();
		for (long long int j = 0; j < size2; ++j)
			output << i << ", " << j << ", " << vConsolidated[i].at(j).iParentStart << ", " << vConsolidated[i].at(j).iChromosome << ", " << vConsolidated[i].at(j).sParentRead << endl;
	}

	output.close();

	return 0;
}
*/



/************************************************************

Merge clusters()

merge every two consectuive clusters, unless they are disconnected (the last read in the left cluster does nt intersect with the first read of the right cluster.)
 
 *************************************************************/

void mergeClusters(){


cout<<" \n Merging neighboring clusters......\n";
vector<t_consolidated> temp;

int endLeft;
int startRight;

//we need

int size = vConsolidated.size(); //stop one cluster before last, where we merge every consecutive two clusters

//initialize an array with the size of vconsolidated to flag merged clusters for removal.
int flags[size];
for(int i=0; i<size; i++)
	flags[i]=0;


for(int i =0; i<size-1; i++){

	
	endLeft = vConsolidated[i][ vConsolidated[i].size() - 1 ].iParentStart + vConsolidated[i][ vConsolidated[i].size() - 1 ].sParentRead.length()-1;
	startRight = vConsolidated[i+1][ 0 ].iParentStart;
	
	if(endLeft >= startRight){
	
	//mark the single clusetrs as merged. 
	flags[i]=1;
	flags[i+1] = 1;
	
	//cout<<" merging: "<<i<<"  and "<<i+1<<endl;
	temp.clear();
	// add new cluster
	//start copying
	for(int j=0; j<	vConsolidated[i].size(); j++){
		temp.push_back(vConsolidated[i][j]);
		//cout<<"****** "<<temp[i].
	}
	
	for(int j=0; j<	vConsolidated[i+1].size(); j++)
		temp.push_back(vConsolidated[i+1][j]);
	
	
	//now push back in vConsolidated
	vConsolidated.push_back(temp);
	}

  }

//now remove the flaged clusters.
for(int i=size-1; i>=0; i--)
	if(flags[i] ==1)
		vConsolidated.erase(vConsolidated.begin()+i);


}



/***************************************************************

 Get depth (coverage) in a cluster.

*****************************************************************/


int getDepthCluster(int i){ //i is the cluster number in vConsolidated

	int depth=0;
	
	int size = vConsolidated[i].at(0).sParentRead.size();
	
	//initilaize an array of the same length to 0
	int count[size];
	for(int k=0; k<size; k++)
		count[k]=0;
	
	//for each read, go over every character and add to count 1 of that char if it is not "-"
	long long clusterSize=vConsolidated[i].size();
	for(long long int k=0; k<clusterSize; k++)
		for(int g=0; g<size; g++)
			if(vConsolidated[i].at(k).sParentRead.at(g) != '-')
				count[g]++;

	for(int k=0; k< size; k++)
		if(count[k] > depth)
			depth = count[k];
	
	return depth;

}

/*
sParentRead = sConsensus;
		consensusRead.iParentStart
		
		$ water -asequence Consensus1_cluster2.txt -bsequence Consensus2_cluster2.txt -gapopen 100 -gapextend 10 -outfile cluster2.water
*/


void alignConsensusMerge(){
	 //temporary container for the newly merged clusters consensus
	 vector<t_consolidated> temp;
	 temp.reserve(vCandidateRegions.size());
	 string command="";
	 string result = "";
	 string seq1="";
	 string seq2="";
	 string token="";

	 
	 
	 int i;
	 for( i=0; i< vCandidateRegions.size()-1; i++ ){
	 	//if the two cluster consensus read intersect, 
	 	seq1= "";
	 	seq2="";
	 	if(vCandidateRegions[i].iChromosome == vCandidateRegions[i+1].iChromosome){
	 		if((vCandidateRegions[i].iParentStart + vCandidateRegions[i].sParentRead.size()) > vCandidateRegions[i+1].iParentStart ){
	 			command = "echo \">Seq1\n"+vCandidateRegions[i].sParentRead+"\" > "+sProjectDirectory+"s1.txt ; "+ "echo \">Seq2\n"+vCandidateRegions[i+1].sParentRead+"\" > "+sProjectDirectory+"s2.txt";
	 			system(command.c_str());
	 			
	 			command = "water -asequence "+sProjectDirectory+"s1.txt -bsequence "+sProjectDirectory+"s2.txt -gapopen 100 -gapextend 10 -auto -outfile "+sProjectDirectory+"waterOut.water; cat "+sProjectDirectory+"waterOut.water | grep -v '#' | grep Seq* ";
	 			result = exec(command.c_str()); //this function will catch and return the sequences printed to stdout
	 			
	 			//the listed sequences are saved in result
	 			istringstream iss(result);
	 			while(iss>>token){
	 				if(token.compare("Seq1") == 0 ){
	 					iss>>token;
	 					iss>>token;
	 					//seq1 = seq1+token.substr(0, token.size()-1);
	 					seq1 = seq1+token;
	 					iss>>token;
	 				}
	 				
	 				else if(token.compare("Seq2") == 0 ){
	 					iss>>token;
	 					iss>>token;
	 					//seq2 = seq2+token.substr(0, token.size()-1);
	 					seq2 = seq2+token;
	 					iss>>token;
	 				}
	 			}//end while
	 			
	 			//special case: if one of the two aligned sequences in water file is equal or larger than its
	 			// original sequence, then get rid of both sequences.
	 			if(seq1.size() >= vCandidateRegions[i].sParentRead.size() || seq2.size() >= vCandidateRegions[i+1].sParentRead.size())
	 				continue;
	 			
	 			
	 			//now merge both in the same clutser
	 			t_consolidated t;
	 			t.iParentStart = vCandidateRegions[i].iParentStart;
				t.iChromosome = vCandidateRegions[i].iChromosome;
				t.bBirCandidateFound = vCandidateRegions[i].bBirCandidateFound;
				if(vCandidateRegions[i].depth>vCandidateRegions[i+1].depth)
					t.depth = vCandidateRegions[i].depth;
				else 
					t.depth = vCandidateRegions[i+1].depth;
				
				t.sParentRead = vCandidateRegions[i].sParentRead + vCandidateRegions[i+1].sParentRead.substr(seq2.size()-1);
				
				temp.push_back(t);
	 			//since we are merging, advance i by one 
	 			i = i+1;
	 		}
	 		else{ //the two sequences do not intersect
	 			temp.push_back(vCandidateRegions[i]);
	 		}
	 	}
	 	else{//the two sequences belong to different chromosoms. 
	 		temp.push_back(vCandidateRegions[i]);
	 	}
	 }
	 //catch the last cluster in case it was not merged with the one preceeding it
	 if(i == vCandidateRegions.size()-1 )
	 	temp.push_back(vCandidateRegions[i]);
	 
	 //done merging step. Copy the new clusters in temp back to original vCandidateRegions
	 vCandidateRegions.clear();
	 vCandidateRegions.reserve(temp.size());
	 for(i=0; i<temp.size(); i++)
	 	vCandidateRegions.push_back(temp[i]);
	 
	 //clear temp
	 temp.clear();
	 
}

/*
 * ************************************************************
 * getConsensus
 *
 * This function takes the grouped (consolidated) reads and makes them all the same length by adding '-' to the beginning and end.
 *
 * For example, if the reads are:
 *
 *   AACGTCGA								  	--AACGTCGA---
 * CGAACGTC			will be transformed into    CGAACGTC-----
 *     CGTCGACGT								----CGTCGACGT
 *
 * This helps for the the next step which is calculate the base calls at each location.
 */
 
 
void getConsensus(){
	cout << "\nMaking reads same length..." << endl;
	fLogFileOut << "\nMaking reads same length..." << endl;

	long long int iLowestStart;
	long long int iLongest;
	long long int iCurrStart;
	long long int diff;
	long long int size = 0;
	string currString;
	long long int sizeCons = vConsolidated.size();
	long long int fivePercent = sizeCons / 20;


	// make all the reads in each consolidation have the same starting polong long int
	for ( long long int i = 0; i < sizeCons; ++i){
	
		if (i % fivePercent == 0)
			cout << "consolidated: " << (i+1) << " of " << sizeCons << " (" << ((i * 100) / sizeCons) << "%)" << endl;
			
			
		size = vConsolidated[i].size();
		iLowestStart = vConsolidated[i].at(0).iParentStart;
		for (long long int j = 1; j < size; ++j){
		//DEBUGGING
			
			iCurrStart = vConsolidated[i].at(j).iParentStart;
			if (iLowestStart > iCurrStart)
				iLowestStart = iCurrStart;
	}
	
		// Now we have the lowest starting polong long int, let's add '-' to the beginning so they all match up
		for (long long int j = 0; j < size; ++j){
		//DEBUGGING
			
			iCurrStart =  vConsolidated[i].at(j).iParentStart;
			currString = vConsolidated[i].at(j).sParentRead;
			diff = iCurrStart - iLowestStart;
			for (long long int k = 0; k < diff; ++k){
				currString = "-" + currString;
				++iCurrStart;
			}
			vConsolidated[i].at(j).sParentRead = currString;
			currString = "";
		}
		
		// Let's repeat only adding '-' to the end
		iLongest = vConsolidated[i].at(0).sParentRead.length();
		for (long long int j = 1; j < size; ++j){
		//DEBUGGING
			
			iCurrStart = vConsolidated[i].at(j).sParentRead.length();
			if (iLongest < iCurrStart)
				iLongest = iCurrStart;
		}

    
		for (long long int j = 0; j < size; ++j){
		
			iCurrStart = vConsolidated[i].at(j).sParentRead.length();
			currString = vConsolidated[i].at(j).sParentRead;
			for (long long int k = iCurrStart; k < iLongest; ++k){
				currString = currString + "-";
				++iCurrStart;
			}
			
		
			vConsolidated[i].at(j).sParentRead = currString;
			currString = "";
		}
	}
	cout << "exiting..." << endl;
	ofstream output;
	output.open((sProjectDirectory + "clustered_locations2.txt").c_str());

	output << "i\tj\tstart\tchr\tread" << endl;
	long long int size2 = vConsolidated.size();
	long long int size3 = 0;
	for (long long int i = 0; i < size2; ++i) {
		size3 = vConsolidated[i].size();
		vConsolidated[i].at(0).depth = getDepthCluster(i);
		
		for (long long int j = 0; j < size3; ++j){
					
			//output << i << ", " << j << ", " << vConsolidated[i].at(j).iParentStart << ", " << vConsolidated[i].at(j).iChromosome << ", " << vConsolidated[i].at(j).sParentRead << endl;
					output << i << ", " << j << ", " << vConsolidated[i].at(j).iParentStart << ", " << vConsolidated[i].at(j).iChromosome << ", " << vConsolidated[i].at(j).sParentRead <<endl;
		}
		
		output << endl;
	}

	output.close();
}

/*
 **************************************************************
 *	clusterClass()
 *
 *	This function finds the number of aligned/unaligned/dashe bases in each cluster.
 *	The purpose is to help classify clusters into categories: ideal/flipped/stray
 *
 */
  
//helper function to count the number of intersected bases
//--ignore if one or both of the bases are dashes 
bool intersect(string l, string r){
	int count=0;
	int nonDashes=0;
	for(int j=0; j<l.size(); j++){
		if(l[j] != '-' && r[j] != '-'){
			nonDashes++;
			if(l[j] == r[j] )
				count++;
		}
	}
	
	if((double) count/nonDashes > 0.9)
		return true;
	else return false;
}
 
 //helper function to find the number of bases needed to shift right anchored reads
int shiftCount(int i, int l, int r){
	
	int j=0; 
	int size = vConsolidated[i][l].sParentRead.size();
	string left = vConsolidated[i][l].sParentRead;
	string right = vConsolidated[i][r].sParentRead;
	
	for( j=0; j<size;  j++){
		//add a dash to right of left anchored, and a dash to left of right anchored
		left = left + "-";
		right = "-" + right;
		
		if(intersect( left, right))
			break;
	} 
	return j+1;
}



int clusterClass(int i, double ratio){

	//check point: if cluster size is small, return
	if(vConsolidated[i].size() < 8)
		return 1;
	/////End of Debug
	
	int readSize=vConsolidated[i][0].sParentRead.size();
	int A[readSize];
	int C[readSize];
	int G[readSize];
	int T[readSize];
	int sum[readSize];//sum of non-dashe bases
	int max=0;
	int type1=0;
	int type2=0;
	int col=0;//to count number of 
	int finalType=0;
	string downStr="";
	string upStr="";
	//initialize to zero
	for(int j=0; j<readSize; j++){
		A[j]=0;
		C[j]=0;
		G[j]=0;
		T[j]=0;
		sum[j]=0;
	}
	
	for(int j=0; j<vConsolidated[i].size(); j++){
		for(int k=0; k<readSize; k++){
			if(vConsolidated[i][j].sParentRead[k]=='A')
				A[k]++;
			else if(vConsolidated[i][j].sParentRead[k]=='C')
				C[k]++;
			else if(vConsolidated[i][j].sParentRead[k]=='G')
				G[k]++;
			else if(vConsolidated[i][j].sParentRead[k]=='T')
				T[k]++;
			
			if(vConsolidated[i][j].sParentRead[k] != '-')
				sum[k]++;
		}
	}
	
	//now find the column with max number of non-dashe bases
	for(int j=0; j<readSize; j++){
		if(sum[j]>max)
			max = sum[j];
	}
	

	//Consider columns with non-dashe sum >60% -- may change later
	for(int j=0; j<readSize; j++){
		if((double)sum[j]/max >0.6){
			col++;
			if( ((double) A[j]/sum[j])> ratio || ((double) C[j]/sum[j])> ratio || ((double) G[j]/sum[j])> ratio || ((double) T[j]/sum[j])> ratio  )
				type1++;
			else type2++;
		}
	}
	
	if((double) type2/col > 0.3)
		finalType = 2;
	else return 1; //no need to continue, the rest is meant for type2 (non-regular) only
	

	// start the process to shift the right anchored one until every column has a majority of at least 90% equal bases
	int lastLeft=-1;//the index of last left appearing before a right anchored read.
	int firstRight = -1;
	//to resolve the stray reads problem:
	// - start from last read, and go up: find lowest left anchored read such that it is not stray
	// - then from the last left, go down, and find the first right such that it is not stray.
	for(int j=vConsolidated[i].size()-1; j>0; j--){
		if( (vConsolidated[i][j].bAnchorLeft == true && vConsolidated[i][j].iFlag != 16) || (vConsolidated[i][j].bAnchorLeft == false && vConsolidated[i][j].iFlag == 16) ){ //if next to current is right anchored
				lastLeft = j;
				break;
		}
	}
	//cout<<"after first lastLeft Computed\n";
	//safety check
	if(lastLeft == -1)
		return 1;
	//now find the last left such that it is not stray
	for(int j= lastLeft; j>0; j--){
		if( (vConsolidated[i][j].bAnchorLeft == true && vConsolidated[i][j].iFlag != 16) || (vConsolidated[i][j].bAnchorLeft == false && vConsolidated[i][j].iFlag == 16) ){ 
			if( (vConsolidated[i][j-1].bAnchorLeft == true && vConsolidated[i][j-1].iFlag != 16) || (vConsolidated[i][j-1].bAnchorLeft == false && vConsolidated[i][j-1].iFlag == 16) ){
				downStr = vConsolidated[i][j].sParentRead;
				upStr = vConsolidated[i][j-1].sParentRead;
				if(intersect(downStr, upStr)){
					lastLeft = j;
					break;
				}
			}
		}
	}
		//cout<<"after second lastLeft Computed\n";
	//safety check
	if(lastLeft == -1 || lastLeft >= vConsolidated[i].size()-2)
		return 1;
	//go from lastLeft down, and find the first non-stray righ anchored read
	for(int j=lastLeft+1; j<vConsolidated[i].size()-1; j++){
		if( (vConsolidated[i][j].bAnchorLeft == false && vConsolidated[i][j].iFlag != 16) || (vConsolidated[i][j].bAnchorLeft == true && vConsolidated[i][j].iFlag == 16) ){ 
			if( (vConsolidated[i][j+1].bAnchorLeft == false && vConsolidated[i][j+1].iFlag != 16) || (vConsolidated[i][j+1].bAnchorLeft == true && vConsolidated[i][j+1].iFlag == 16) ){
				downStr = vConsolidated[i][j].sParentRead;
				upStr = vConsolidated[i][j+1].sParentRead;
				if(intersect(downStr, upStr)){
					firstRight= j;
					break;
				}
			}
		}
	}
		//cout<<"after first firstRight Computed\n";
	//safety check
	if(firstRight == -1)
		return 1;
	
	//start shifting the right to right

	int shift = shiftCount(i, lastLeft, firstRight );

	if(shift > 0){

	//form the dashes string to be added to each read
		string addition="";
		for(int j=0; j<shift; j++)
			addition = addition + "-";
	
		for(int j=0; j<vConsolidated[i].size(); j++){
			if(vConsolidated[i][j].bAnchorLeft == true){
				if(vConsolidated[i][j].iFlag != 16) //non-inverted read
					vConsolidated[i][j].sParentRead = vConsolidated[i][j].sParentRead + addition;
				else 	
					vConsolidated[i][j].sParentRead =   addition + vConsolidated[i][j].sParentRead ;
			}
			else{ //add to left side
				if(vConsolidated[i][j].iFlag != 16) //non-inverted read
					vConsolidated[i][j].sParentRead =   addition + vConsolidated[i][j].sParentRead ;
				else 
					vConsolidated[i][j].sParentRead = vConsolidated[i][j].sParentRead + addition;
			}
		}
	}
	
	return finalType;  
}

 
 
/*
 * ************************************************************
 * consolidateBaseCalls
 *
 * This is basically a modified de novo assembly method that takes the base call frequency at each location to create a new read.
 */
void consolidateBaseCalls(){
	cout << "\nCalculating consensus base calls..." << endl;
	fLogFileOut << "\nCalculating consensus base calls..." << endl;

	long long int iConsolidatedSize = vConsolidated.size();
	long long int iCurrSize = 0;
	long long int arr[85];
	long long int numTot = 0;
	long long int iReadLength = 0;
	string blank = "";
	string sConsensus = ""; // the consensus string
	long long int iMinStartPos = 0;
	string sCurrChar;
	long long int iHighestProb;
	long long int fivePercent = iConsolidatedSize / 20;
	t_consolidated consensusRead;
	int depth;
	int type;
	 string command="";
	 string result = "";
	 string seq1="";
	 string seq2="";
	 string token="";
	 string tempConsensus;
	  long long int w;
	 
	/*
	 * Memory is starting to become an issue. To compensate for this, we will start deleting the vConsolidated cluster after the vCandidateRegions
	 * struct is added. However, erasing in a vector is inefficient since all the memory is copied. There is one way to compensate for this, start from
	 * the back. Since it doesn't matter which cluster we start on, and reallocation won't be affected erasing from the back, let's reverse traverse the
	 * vector.
	 *
	 * However, we need to start rearranging previous methods to start from the back as well. Start with the sorting algorithm and make it so the largest
	 * chromosome is at the front of the vector.
	 */
	// TODO erase starting from the back.

	for (long long int i = 0; i < iConsolidatedSize; ++i){
		if (i % fivePercent == 0)
			cout << "consolidated: " << i << " of " << iConsolidatedSize << " (" << ((i * 100) / iConsolidatedSize) << "%)" << endl;

		// get the address to make lookups faster
		vector<t_consolidated>& curr = vConsolidated[i];
		iReadLength = curr[0].sParentRead.length();
		sConsensus = "";
		depth = curr[0].depth;
		//type = curr[0].type;
		

		iCurrSize = curr.size();
		
		//find min start position
		iMinStartPos = curr[0].iParentStart;
		for (long long int j = 1; j < iCurrSize; ++j){
			if (curr[j].iParentStart < iMinStartPos)
				iMinStartPos = curr[j].iParentStart;
		}

		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//////HERE WE NEED TO SPLIT CODE TO DO ALIGNMENT FOR EACH SUBCLUSTER (ONLY LEFT ARE ALIGNED< THEN ONLY RIGHTS ARE ALIGNED, THEN ONLY LEFT.....)
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		//divide the the cluster into subclusters by giving two values k and currSize
		//    such that all the reads from k to k_end (exclusive) are left (or all are right)-anchored ones
		//   Then, get one consensus reads and aligne it to previous fround one.  
		long long int k;
		long long int k_end=-1; 
								//-1 because we would like to to increment k to be k_end+1 at the start of each cycle in the loop
		bool anchored = true; // true is left, and right is false--change once you get in the loop, so
								// if we skip a stray read, we would have changed the next anchored subcluster
		 tempConsensus="";
		int depth_prev=0;
		while(true){ //New for loop to get consensus for subclusters
			tempConsensus = ""; //use this string to save the temporary consensus of the subcluster; ALign it to sConsensus
			//find k and k_d
			k = k_end +1;
			k_end = k;
			//DEBUGGING
			//cout<<"Before deciding on outer loop........\n";
			if(k_end >= iCurrSize-1 || k >= iCurrSize-1){ //we already hit the last cluster
				//cout<<"Breaking bigger while loop....Anchored = "<<anchored<<"\n\n";
				break;
			}
				
			while(true){
				if(curr[k_end].bAnchorLeft == anchored && k_end < iCurrSize )
					k_end++;
				else {
					//cout<<"Breaking inner loop\n";
					break;
				}
			}
			//cout<<"i "<<i<<" k "<<k<<" k_end"<<k_end<<endl;
			//anchored ^= true; //flip from left to right (or from right to left)
			if(anchored == true)
				anchored = false;
			else anchored = true;
			//cout<<"Anchored = "<<anchored<<"\n\n";
			
			if(k == k_end-1)
				continue;
			
			
		//for each base j in all reads: (fix base j)
			for (long long int j = 0; j < iReadLength; ++j){

				// initialize array and variables to 0s
				for (long long int u = 0; u < 85; ++u)
					arr[u] = 0;
				numTot = 0;

				//go over all reads in cluster, and find the highest frequency base.
				for (  w=k ; w < k_end; ++w){ ///Note: we assume that k_end always point to the last read in the subcluster
					//cout<<"Within for loop for coutning highest freguency...i = "<<i<<" and w = "<<w<<endl;
					++arr[(long long int) curr[w].sParentRead.at(j)];
					if (curr[w].sParentRead.at(j) != '-')
						++numTot;
				}
				//cout<<" after each k to k_end.."<<"k "<<k<<" k_end"<<k_end<<endl; 
				//curr.clear();
				iHighestProb = 0;
	
				// -s
				if (numTot == 0)
					continue;
				// As
				if ((arr[65] * 10) / numTot > iHighestProb){
					iHighestProb = (arr[65] * 10) / numTot;
					sCurrChar = "A";
				}
				// Cs
				if ((arr[67] * 10) / numTot > iHighestProb){
					iHighestProb = (arr[67] * 10) / numTot;
					sCurrChar = "C";
				}
				// Gs
				if ((arr[71] * 10) / numTot > iHighestProb){
					iHighestProb = (arr[71] * 10) / numTot;
					sCurrChar = "G";
				}
				// Ts
				if ((arr[84] * 10) / numTot > iHighestProb){
					iHighestProb = (arr[84] * 10) / numTot;
					sCurrChar = "T";
				}
				
				tempConsensus += sCurrChar;
				sCurrChar = "-";
			}
			//DEBUGGING
			//cout<<"tempConsensus "<<tempConsensus<<endl<<"sConsensus "<<sConsensus<<endl;
			
			if(sConsensus == ""){ //not aligned yet with any subcluster
				sConsensus = tempConsensus;
				//cout<<"IN sConsensus = tempConsensus and sConsensus is "<<sConsensus<<"\n";
				continue; //Do not align in this case, since this is the first subcluster
			}
			//cout<<" Past sConsensus.....\n";
			///// ALIGN HERE
			//sConsensus=""; //////ALIGN TEMPCONSENSUS WITH THIS
			////
			//cout<<" Past ECHO.....\n";
			seq1= "";
	 		seq2="";
	 		
	 		//
	 		if(tempConsensus.size() == 0)
	 			continue;
	 		
	 			command = "echo \">Seq1\n"+sConsensus+"\" > "+sProjectDirectory+"s1.txt ; "+ "echo \">Seq2\n"+tempConsensus+"\" > "+sProjectDirectory+"s2.txt";
	 			system(command.c_str());

	 			//command = "water -asequence s1.txt -bsequence s2.txt -gapopen 100 -gapextend 10 -auto -outfile waterOut.water; cat waterOut.water | grep -v '#' | grep Seq* ";
	 						//needle -asequence seq1 -bsequence seq2 -gapopen 100 -gapextend 10 -outfile out.needle
	 			command = "needle -asequence "+sProjectDirectory+"s1.txt -bsequence "+sProjectDirectory+"s2.txt -gapopen 100 -gapextend 10 -auto -outfile "+sProjectDirectory+"waterOut.water; cat "+sProjectDirectory+"waterOut.water | grep -v '#' | grep Seq* ";
	 			result = exec(command.c_str()); //this function will catch and return the sequences printed to stdout
				//cout<<"Result:\n"<<result<<endl;
	 			//the listed sequences are saved in result
	 			istringstream iss(result);
	 			while(iss>>token){
	 				if(token.compare("Seq1") == 0 ){
	 					iss>>token;
	 					iss>>token;
	 					//seq1 = seq1+token.substr(0, token.size()-1);
	 					seq1 = seq1+token;
	 					iss>>token;
	 				}
	 				
	 				else if(token.compare("Seq2") == 0 ){
	 					iss>>token;
	 					iss>>token;
	 					//seq2 = seq2+token.substr(0, token.size()-1);
	 					seq2 = seq2+token;
	 					iss>>token;
	 				}
	 				
	 				
	 			}//end while
	 			/////DEBUGGING
	 			
	 			//cout<<"tempConsensus "<<tempConsensus<<endl<<"sConsensus "<<sConsensus<<endl;
	 			//cout<<"seq1 "<<seq1<<endl<<"seq2 "<<seq2<<endl;
	 			
	 			
	 			//Now merge the two alined sequences into one with the following criteria:
	 			// if at position v, both have bases, we take the base from the sequence with larger depth
	 			sConsensus = ""; 
	 			for(int v=0; v<seq1.size(); v++){
					if(depth_prev > (k_end - k)){
	 					if(seq1[v]!='-')
	 						sConsensus +=seq1[v];
	 					else 	
	 						sConsensus +=seq2[v];
	 					}
	 				else{
	 					if(seq2[v]!='-')
	 						sConsensus +=seq2[v];
	 					else 	
	 						sConsensus +=seq1[v];
	 				}
	 			}
	 			depth_prev = k_end - k;
	 			/*
	 			sConsensus = ""; 
	 			for(int v=0; v<seq1.size(); v++){
	 				if(seq1[v]!='-')
	 					sConsensus +=seq1[v];
	 				else 	
	 					sConsensus +=seq2[v];
	 			}*/
	 			//special case: if one of the two aligned sequences in water file is equal or larger than its
	 			// original sequence, then get rid of both sequences.
	 			//if(seq1.size() >= vCandidateRegions[i].sParentRead.size() || seq2.size() >= vCandidateRegions[i+1].sParentRead.size())
	 			//	continue;
	 			///Edit sConsensus such that: sConsensus = sConsensus + tempConsenss(size of seq 1)
				//if(seq1.size() >0 && seq2.size() > 0)
					//sConsensus = sConsensus + tempConsensus.substr( seq1.size()  );
			///////End of align
		}	

		curr.clear();
		if (sConsensus.length() > 900) // TODO THIS NEEDS TO BE FIXED, BUT FOR NOW WE'LL SEE
			continue;
		consensusRead.sParentRead = sConsensus;
		consensusRead.iParentStart = iMinStartPos;
		consensusRead.iChromosome = curr[0].iChromosome;
		consensusRead.bBirCandidateFound = false;
		consensusRead.depth = depth;
		//consensusRead.type = type;
		vCandidateRegions.push_back(consensusRead);
	}

	// sort the consensus reads
	sort(vCandidateRegions.begin(), vCandidateRegions.end(), compareStart);
}


bool compareStart(const t_consolidated &a, const t_consolidated &b){
	if (a.iChromosome < b.iChromosome) return true;
	if (a.iChromosome == b.iChromosome) return a.iParentStart < b.iParentStart;
	return false;
}
