//============================================================================
// Name        : main.cpp
// Authors     : Matt Segar, modified by Thamer Alsulaiman
// Version     : 3
// Copyright   : 
// Description : Main program
//============================================================================

#define MAIN_CPP_

#include "defs.h"

#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <unistd.h>
   #include <stdexcept>

#include <vector>
#include <sstream>
#include <sys/wait.h>
#include <string>
#include <algorithm>
#include <limits.h>
#include <ctime>
#include <cmath>
#include <map>


using namespace std;

int main(int argc, char *argv[]) {
	// start timing
	time0 = time(NULL);

	// get command line arguments
	int cl = processCommandLine(argc, argv);
	if (cl != 0)
		cout << "Command line exited with: " << cl << endl;

	sBaseFileName = setupBaseFileName();

	// Set up general log file and project directory
	prepareLogFile(fLogFileOut,sBaseFileName,confDB.getKey("sLogDirName").stringVal);
	sProjectDirectory = confDB.getKey("projectDirectory").stringVal;

	// Print the method configuration parameters
	printConfig(fLogFileOut);

	// execute the main alignment programs (BWA and samtools)
	int exec = startExecutables();
	if (exec != 0)
		cout << "Exec exited with: " << exec << endl;
	
	
	//Preprocess files by removing duplicates to simplify the matching of half reads.
	preProcessFiles();
	
	// read in reference genome: read headers for now, then read it in full later once needed
	//readInReferenceGenomeHeadersOnly();
	readInReferenceGenome();
	
	if(confDB.getKey("parMPISec").boolVal == true)
		 //splitSecPhase();
		splitByChr(); ////Split by chromosome
	
	//////////After parallel BWA, we may need to merge files first. secondPhase=false will stop execution
	if(confDB.getKey("secondPhase").boolVal == false)
		return 0;

	// find reads with one half anchored and the other unaligned
	int cand = startCandidateReads();
	if (cand != 0)
		cout << "startCandidateReads exited with: " << cand << endl;

	// consolidate reads to narrow down BIR locations
	int cons = startConsolidate();
	if (cons != 0)
		cout << "startConsolidate exited with: " << cons << endl;

	// read in reference genome: whole reference this time 
	//vReferenceGenome.clear();
	//readInReferenceGenome();

	// perform alignments to get candidate BIR locations
	int bir = startBirFinder();
	if (bir != 0)
		cout << "startBirFinder exited with: " << bir << endl;

	// we have the possible bir strings and their respective locations so let's find the template to confirm
	int temp = startTemplateFinder();
	if (temp != 0)
		cout << "startTemplateFinder exited with: " << temp << endl;

	return 0;
}


int processCommandLine(int argc, char* argv[])
{
	char *pch;
	string sName, sVal;
	string::size_type pos;

	if (argc < 2) {
		cout << "\nMissing configuration file name!\n";
		printUsageAndExit(argv[0]);
	}

	confDB.initializeDB(argv[1]);

	// Now, any additional command line options are designed to override options
	// are in the configuration file
	for(int i = 2; i < argc; i++)
	{
		pch = argv[i];
		if (*pch++ != '-')
			printUsageAndExit(argv[0]);
		if (*pch == '\0')
			printUsageAndExit(argv[0]);

		switch(*pch++)
		{
		case '?':
			printUsageAndExit(argv[0]);
			break;

		case 'O':
			sName = pch;
			pos = sName.find('=');
			if (pos == string::npos || pos + 1 == sName.length())
				break;
			sVal = sName.substr(pos+1);
			sName.erase(pos);
			confDB.setKey(sName,sVal);
			cout << "addConfigOption(" << sName << "," << sVal << ")\n";
			break;

		case 'j':
			i++;
			if (i >= argc)
				printUsageAndExit(argv[0]);
			sJobId = argv[i];
			break;

		default:
			cerr << "Unknown Option: " << (pch - 1) << endl;
			printUsageAndExit(argv[0]);
			break;
		}
	}

	return 0;
}

void printUsageAndExit(char *sName)
{
	cout << "\nUsage: " << sName << " configFile [options]" << endl
			<< " -?                    Command line options\n"
			<< " configFile            Program configuration file name\n"
			<< " -j jobIdString        Identifier to be used for this job\n"
			<< " -OconfOption=Value    Override options in the configuration file here\n\n";

	exit(1);
}



void readInReferenceGenomeHeadersOnly(){
	cout << "\nReading in reference genome..." << endl;
	fLogFileOut << "\nReading in reference genome..." << endl;
	ifstream input;
	t_chromosome chromosome;
	bool first = true;
	int iChr = confDB.getKey("chromosome").intVal;
	int currChr = 0;

	input.open(confDB.getKey("referenceFile").stringVal.c_str());

	// check if file is open
	if (input.is_open() == false){
		cout << "\nThe reference file could not be found: " << confDB.getKey("referenceFile").stringVal << endl;
		exit(1);
	}

	for (string row; getline(input, row, '\n');){
		if (row[0] == '>'){
			if (first){
				chromosome.fastaHeader = row.substr(1);
				first = false;
			} else {
				vReferenceGenome.push_back(chromosome);
				chromosome.fastaHeader = row.substr(1);
				chromosome.sequence = "";
				++currChr;
			}
		} else if (row[0] == ' ')
			continue;
		else {
			if (currChr == iChr || iChr == 0)
					;
				//chromosome.sequence += row;
		}
	}
	vReferenceGenome.push_back(chromosome);

	/*ofstream output;
	output.open("chromosome.fasta");
	for (int i = 0; i < vReferenceGenome.size(); ++i){
		if (vReferenceGenome[i].sequence.length() < 2)
			continue;
		output << ">" << vReferenceGenome[i].fastaHeader << endl;
		int lngth = vReferenceGenome[i].sequence.length();
		for (int j = 0; j < lngth; ++j){
			output << vReferenceGenome[i].sequence.substr(j, 80) << endl;
			j += 79;
		}
	}

	output.close();
	exit(1);*/
	// print reference genome information
	printReferenceGenomeInfo(fLogFileOut);
}


void readInReferenceGenome(){
	cout << "\nReading in reference genome..." << endl;
	fLogFileOut << "\nReading in reference genome..." << endl;
	ifstream input;
	t_chromosome chromosome;
	bool first = true;
	int iChr = confDB.getKey("chromosome").intVal;
	int currChr = 0;

	input.open(confDB.getKey("referenceFile").stringVal.c_str());

	// check if file is open
	if (input.is_open() == false){
		cout << "\nThe reference file could not be found: " << confDB.getKey("referenceFile").stringVal << endl;
		exit(1);
	}

	// int prefixLength=0;
	
	for (string row; getline(input, row, '\n');){
		if (row[0] == '>'){
			if (first){
				chromosome.fastaHeader = row.substr(1);
				first = false;
			} else {
				vReferenceGenome.push_back(chromosome);
				chromosome.fastaHeader = row.substr(1);
				chromosome.sequence = "";
				++currChr;
			}
		} else if (row[0] == ' ')
			continue;
		else {
			if (currChr == iChr || iChr == 0)
				chromosome.sequence += row;
		}
	}
	////////Added prefix length to allow for correct reads referncing against reference 
	//chromosome.refPrefixLength = prefixLength;
	vReferenceGenome.push_back(chromosome);
	//prefixLength += chromosome.sequence.length();
	

	/*ofstream output;
	output.open("chromosome.fasta");
	for (int i = 0; i < vReferenceGenome.size(); ++i){
		if (vReferenceGenome[i].sequence.length() < 2)
			continue;
		output << ">" << vReferenceGenome[i].fastaHeader << endl;
		int lngth = vReferenceGenome[i].sequence.length();
		for (int j = 0; j < lngth; ++j){
			output << vReferenceGenome[i].sequence.substr(j, 80) << endl;
			j += 79;
		}
	}

	output.close();
	exit(1);*/
	// print reference genome information
	printReferenceGenomeInfo(fLogFileOut);
}

/*
 * void setupBaseFileName()
 *
 * Sets up a base filename to use throughout the program for all log files,
 * etc... The file name will be based on the current time/date stamp.
 */
string setupBaseFileName()
{
    string sBaseFileName;
    char sTime[50];
    time_t t;
    tm *tmptr;

    t = time(NULL);
    tmptr = localtime(&t);
    strftime(sTime,50,"%Y%m%d_%H%M",tmptr);

    sBaseFileName = sTime;
    if (sJobId == "")
        sJobId = "0";

    sBaseFileName += "_" + sJobId + "_";

    cout << "BASE FILE NAME: " << sBaseFileName << endl;
    return sBaseFileName;
}

void prepareLogFile(ofstream& fout, string sBaseFileName, string sLogDirName)
{
#define DIRNAME_LEN 1024

	char curwd[DIRNAME_LEN];
    // Get the current working directory
    if (getcwd(curwd, DIRNAME_LEN) == NULL)
        perror("getcwd error");

    string sFile = sLogDirName + "/" + sBaseFileName + "Log.txt";

    // Turn on exceptions for file output stream
    fout.exceptions(ios::failbit|ios::badbit);
    try {
        fout.open(sFile.c_str());
    }
    catch (ios_base::failure& e) {
        throw ios_base::failure(string("Failed to open ") + sFile);
    }

    time_t t;
    t = time(NULL);
    fout << "Log File Started: " << ctime(&t) << "\r\n";
    fout << "Base File Name: " << sBaseFileName << "\r\n";
}



//////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
/////////////// NEW CODE FOR SPLITTING SECOND PHASE FILES and prepare for MPI /////////////////////

	
   string exec2(const char* cmd) {
       char buffer[128];
       string result = "";
       FILE* pipe = popen(cmd, "r");
       if (!pipe) throw runtime_error("popen() failed!");
       try {
      while (!feof(pipe)) {
          if (fgets(buffer, 128, pipe) != NULL)
         result += buffer;
      }
       } catch (...) {
      pclose(pipe);
      throw;
       }
       pclose(pipe);
       return result;
   }
   
   
   

template <typename T>
  string NToString ( T Number )
  {
    ostringstream ss;
    ss << Number;
    return ss.str();
  }


string processFileName(string s, int id){
    if (id <10)
	return (s+"000"+NToString(id));
    if (id <100)
	return (s+"00"+NToString(id));
    if (id <1000)
	return (s+"0"+NToString(id));

    return (s+NToString(id));
    
}

void splitSecPhase()
{
  ifstream input;
  char row_delim = '\n';
  char field_delim = '\t';
  string previous="";
  string prevName = "";
  ///////////////// To split second phase files and distribute to several MPI:
  ///////////////// 1- remove any two half consecutive reads if they belong to the same read,
  ////////////////// this will eliminate the reads that either have two aligned, or unaligned halfs. This will 
  /////////////////      eleminate the need to use maps to match half reads   
  
  ////////// Start by writing the unaligned files
  //input.open ((sProjectDirectory + sUnalignedFile).c_str ());
  ofstream output;
  output.open((confDB.getKey("projectDirectory").stringVal+"tempUnaligned").c_str());
  input.open ((confDB.getKey("projectDirectory").stringVal+confDB.getKey("unalignedFile").stringVal+"_2.sam").c_str());
  vector < string > curr;
  vector < string > curr2;
  string row;
  
  long long int max=0;
  
  for (row; getline (input, row, row_delim);)
    {
       if(row[0]=='@'){
      	output<<row<<endl;
      	continue;
      }

      // reset vector
      curr.clear ();
      istringstream ss (row);
      for (string word; getline (ss, word, field_delim);)
	{
	  curr.push_back (word);
	}
     
     if(curr[0].erase(curr[0].size()-2).compare(prevName) == 0)    ///both belong to the same parent read
     {
     	prevName = "";
     	previous = "";
     	continue;
     }
     else{
  
     	if(previous.compare("") != 0)   //not an empty string
     	{	
     		output<<previous<<endl;
     	}
     	previous = row;
     	prevName = curr[0];
     }
 }
    
    if(previous.compare("")!=0)  //write the last row
    	output<<previous<<endl; ///////////////////////%%%%%%%%%%%%%%%%%%% CHECK IF ENDL IS NEEDED
    input.close();
    output.close();

////////////////////////////////////////// END OF WRITING unaligned file /////////////////////////////////////


///////////////////////////////////////// START OF WRITING aligned files //////////////////////////////////////////
 previous="";
  prevName = "";
  //input.open ((sProjectDirectory + sUnalignedFile).c_str ());
  
  output.open((confDB.getKey("projectDirectory").stringVal+"tempAligned").c_str());
  input.open ((confDB.getKey("projectDirectory").stringVal+confDB.getKey("finalAlignedFile").stringVal+".sam").c_str());
 

  for (row; getline (input, row, row_delim);)
    {
       if(row[0]=='@'){
      	output<<row<<endl;
      	continue;
      }
      // reset vector
      curr.clear ();
      istringstream ss (row);
      for (string word; getline (ss, word, field_delim);)
	{
	  curr.push_back (word);
	}
      
      long long int startPos;
	sscanf(curr[3].c_str(), "%lld", &startPos);
	if(max<startPos)
		max = startPos;     
     if(curr[0].erase(curr[0].size()-2).compare(prevName) == 0)    ///both belong to the same parent read
     {
     	prevName = "";
     	previous = "";
     	continue;
     }
     else{
     	if(previous.compare("") != 0)   //not an empty string
     	{	
     		output<<previous<<endl;
     	}
     	previous = row;
     	prevName = curr[0];
     }
    }
    
    if(previous.compare("")!=0)  //write the last row
    	output<<previous<<endl; ///////////////////////%%%%%%%%%%%%%%%%%%% CHECK IF ENDL IS NEEDED
    
    input.close();
    output.close();
    ////////////////////////// Done writing the aligned file /////////////////////////////////
    
    ///// After writing the new files, remove old ones, and rename the new ones.

    string command = "rm "+confDB.getKey("projectDirectory").stringVal+confDB.getKey("finalAlignedFile").stringVal+".sam";
    system(command.c_str());
         command = "rm "+confDB.getKey("projectDirectory").stringVal+confDB.getKey("unalignedFile").stringVal+"_2.sam";
    system(command.c_str());
    
    command = "mv "+confDB.getKey("projectDirectory").stringVal+"tempAligned "+confDB.getKey("projectDirectory").stringVal+confDB.getKey("finalAlignedFile").stringVal+".sam";
    system(command.c_str());
    command = "mv "+confDB.getKey("projectDirectory").stringVal+"tempUnaligned "+confDB.getKey("projectDirectory").stringVal+confDB.getKey("unalignedFile").stringVal+"_2.sam";
    system(command.c_str());
    
/////////////////////////////////////// DONE THROWING DUPLICATES FROM aligned and unaligned files ////////////////////

////////////////////////////////////// START SPLITTING INTO DIFFERENT FILES before starting MPI processes ///////////////

	// First: count number of characters in the reference file
	//confDB.getKey("referenceFile").stringVal;
	
	/* command = "wc -m < "+confDB.getKey("referenceFile").stringVal;
	string res = exec2(command.c_str());
	long long int numChars; 
        sscanf(res.c_str(), "%lld", &numChars);
	*/
	
	int numNodes = confDB.getKey("numNodesSec").intVal;
	long long int range = max / (numNodes );
	
	cout<<"Num of chars(MAX): "<<max<<" and RANGE : "<<range<<endl;
	
	///// Second: open unaligned and aligned files as inputs:
	ifstream aligned;
	ifstream unaligned;
	
	aligned.open((confDB.getKey("projectDirectory").stringVal+confDB.getKey("finalAlignedFile").stringVal+".sam").c_str());

	unaligned.open((confDB.getKey("projectDirectory").stringVal+confDB.getKey("unalignedFile").stringVal+"_2.sam").c_str());
	
	//Third: open the output files for each processor employed.
	
	ofstream alignedFiles[numNodes];
	ofstream unalignedFiles[numNodes];
	
	for(int i = 0; i< numNodes; i++){
		ostringstream filename;
		string fn = processFileName(confDB.getKey("projectDirectory").stringVal+confDB.getKey("finalAlignedFile").stringVal, i);
		
		filename << fn<<".sam";
		alignedFiles[i].open(filename.str().c_str());
	}
	
	for(int i = 0; i< numNodes; i++){
		ostringstream filename;
		string fn = processFileName(confDB.getKey("projectDirectory").stringVal+confDB.getKey("unalignedFile").stringVal, i);
		
		filename << fn<<"_2.sam";
		unalignedFiles[i].open(filename.str().c_str());
	}
	
	/////Start writing
	string row2;
	
	for (row; getline (aligned, row, row_delim);)
    {
    	getline (unaligned, row2, row_delim);
       
       if(row[0]=='@'){
       
      	for(int j=0; j<numNodes; j++){
      		alignedFiles[j]<<row<<endl;
      		unalignedFiles[j]<<row2<<endl;
      		}
      		
      	continue;
      }

      // reset vector
      curr.clear ();
      istringstream ss (row);
      for (string word; getline (ss, word, field_delim);)
	{

	  curr.push_back (word);
	}

	////Check the range of the read
	long long int startPos;
	sscanf(curr[3].c_str(), "%lld", &startPos);
	

	for(int j=0; j<numNodes; j++){
		//if( atoi(curr[3].c_str()) <= ((j+1) * range))
		if( startPos <= ((j+1) * range))
		{ 	
			alignedFiles[j]<<row<<endl;
			unalignedFiles[j]<<row2<<endl;
			break;	
		}
	}
	} /////END of writing phase.
	
	///////CLOSE FILES.
	aligned.close();
	unaligned.close();
	
	for(int j=0; j<numNodes; j++){
		alignedFiles[j].close();
		unalignedFiles[j].close();
	}
	
	cout<<".......MAX position found is :"<<max<<endl;

  return ;
}

/*
*************************************************************************************************
			Preprocess files by removing duplicates in aligned and unaligned files.
			This will allow the matching process to be done by streaming files, instead of
			using dictionaries/maps.
************************************************************************************************
*/
void preProcessFiles(){


  ifstream input;
  char row_delim = '\n';
  char field_delim = '\t';
  string previous="";
  string prevName = "";
  
  ///////////////// To split second phase files and distribute to several MPI:
  ///////////////// 1- remove any two half consecutive reads if they belong to the same read,
  ////////////////// this will eliminate the reads that either have two aligned, or unaligned halfs. This will 
  /////////////////      eleminate the need to use maps to match half reads   
  
  ////////// Start by writing the unaligned files
  //input.open ((sProjectDirectory + sUnalignedFile).c_str ());
  ofstream output;
  output.open((confDB.getKey("projectDirectory").stringVal+"tempUnaligned").c_str());
  input.open ((confDB.getKey("projectDirectory").stringVal+confDB.getKey("unalignedFile").stringVal+"_2.sam").c_str());
  vector < string > curr;
  vector < string > curr2;
  string row;
  
  //////DEBUGGING
  cout<<" In Split by chromosome function ....\n";
  
  long long int max=0;
  
  for (row; getline (input, row, row_delim);)
    {
       if(row[0]=='@'){
      	output<<row<<endl;
      	continue;
      }

      // reset vector
      curr.clear ();
      istringstream ss (row);
      for (string word; getline (ss, word, field_delim);)
	{
	  curr.push_back (word);
	}
     
     if(curr[0].erase(curr[0].size()-2).compare(prevName) == 0)    ///both belong to the same parent read
     {
     	prevName = "";
     	previous = "";
     	continue;
     }
     else{
  
     	if(previous.compare("") != 0)   //not an empty string
     	{	
     		output<<previous<<endl;
     	}
     	previous = row;
     	prevName = curr[0];
     }
 }
    
    if(previous.compare("")!=0)  //write the last row
    	output<<previous<<endl; ///////////////////////%%%%%%%%%%%%%%%%%%% CHECK IF ENDL IS NEEDED
    input.close();
    output.close();

////////////////////////////////////////// END OF WRITING unaligned file /////////////////////////////////////

//////DEBUGGING 
cout<<" at end of writing unaligned file....\n";

///////////////////////////////////////// START OF WRITING aligned files //////////////////////////////////////////
 previous="";
  prevName = "";
  //input.open ((sProjectDirectory + sUnalignedFile).c_str ());
  
  output.open((confDB.getKey("projectDirectory").stringVal+"tempAligned").c_str());
  input.open ((confDB.getKey("projectDirectory").stringVal+confDB.getKey("finalAlignedFile").stringVal+".sam").c_str());
 

  for (row; getline (input, row, row_delim);)
    {
       if(row[0]=='@'){
      	output<<row<<endl;
      	continue;
      }
      // reset vector
      curr.clear ();
      istringstream ss (row);
      for (string word; getline (ss, word, field_delim);)
	{
	  curr.push_back (word);
	}
      
      long long int startPos;
	sscanf(curr[3].c_str(), "%lld", &startPos);
	if(max<startPos)
		max = startPos;     
     if(curr[0].erase(curr[0].size()-2).compare(prevName) == 0)    ///both belong to the same parent read
     {
     	prevName = "";
     	previous = "";
     	continue;
     }
     else{
     	if(previous.compare("") != 0)   //not an empty string
     	{	
     		output<<previous<<endl;
     	}
     	previous = row;
     	prevName = curr[0];
     }
    }
    
    if(previous.compare("")!=0)  //write the last row
    	output<<previous<<endl; ///////////////////////%%%%%%%%%%%%%%%%%%% CHECK IF ENDL IS NEEDED
    
    input.close();
    output.close();
    ////////////////////////// Done writing the aligned file /////////////////////////////////


//////DEBUGGING 
cout<<" at end of writing Aligned file....\n";


    ///// After writing the new files, remove old ones, and rename the new ones.

    string command = "rm "+confDB.getKey("projectDirectory").stringVal+confDB.getKey("finalAlignedFile").stringVal+".sam";
    system(command.c_str());
         command = "rm "+confDB.getKey("projectDirectory").stringVal+confDB.getKey("unalignedFile").stringVal+"_2.sam";
    system(command.c_str());
    
    command = "mv "+confDB.getKey("projectDirectory").stringVal+"tempAligned "+confDB.getKey("projectDirectory").stringVal+confDB.getKey("finalAlignedFile").stringVal+".sam";
    system(command.c_str());
    command = "mv "+confDB.getKey("projectDirectory").stringVal+"tempUnaligned "+confDB.getKey("projectDirectory").stringVal+confDB.getKey("unalignedFile").stringVal+"_2.sam";
    system(command.c_str());
    
/////////////////////////////////////// DONE THROWING DUPLICATES FROM aligned and unaligned files ////////////////////


}


/*
*
**********************************************************************************************
*			Split by chromosome
**********************************************************************************************
*
**********************************************************************************************
*/
/* 
  This methode splits the files such that every new file have the the reads from a single chromosome
*/
void splitByChr()
{
  ifstream input;
  char row_delim = '\n';
  char field_delim = '\t';
  string previous="";
  string prevName = "";
  string row;
    vector < string > curr;
  
////////////////////////////////////// START SPLITTING INTO DIFFERENT FILES before starting MPI processes ///////////////

	// First: count number of characters in the reference file
	//confDB.getKey("referenceFile").stringVal;
	
	/* command = "wc -m < "+confDB.getKey("referenceFile").stringVal;
	string res = exec2(command.c_str());
	long long int numChars; 
        sscanf(res.c_str(), "%lld", &numChars);
	*/
	
	//Number of nodes will be number of chromosomes
	int numNodes = vReferenceGenome.size();
	cout<<"vReferenceGenome.size() is "<<vReferenceGenome.size()<<endl;
	
	//Now prepare a map to save the name of each chromosome with its index
	map<string,int> chromMap;
	for(int k=0; k<numNodes; k++){
		cout<<"...... "<<vReferenceGenome[k].fastaHeader<<": "<<k<<endl;
		chromMap[vReferenceGenome[k].fastaHeader] = k;
		
	}
	
	///// Second: open unaligned and aligned files as inputs:
	ifstream aligned;
	ifstream unaligned;
	
	aligned.open((confDB.getKey("projectDirectory").stringVal+confDB.getKey("finalAlignedFile").stringVal+".sam").c_str());

	unaligned.open((confDB.getKey("projectDirectory").stringVal+confDB.getKey("unalignedFile").stringVal+"_2.sam").c_str());
	
	//Third: open the output files for each processor employed.
	
	ofstream alignedFiles[numNodes];
	ofstream unalignedFiles[numNodes];
	
	for(int i = 0; i< numNodes; i++){
		ostringstream filename;
		string fn = processFileName(confDB.getKey("projectDirectory").stringVal+confDB.getKey("finalAlignedFile").stringVal, i);
		
		filename << fn<<".sam";
		alignedFiles[i].open(filename.str().c_str());
	}
	
	for(int i = 0; i< numNodes; i++){
		ostringstream filename;
		string fn = processFileName(confDB.getKey("projectDirectory").stringVal+confDB.getKey("unalignedFile").stringVal, i);
		
		filename << fn<<"_2.sam";
		unalignedFiles[i].open(filename.str().c_str());
	}
	
	/////Start writing, but first prepare the 
	string row2;
	
	for (row; getline (aligned, row, row_delim);)
    {
    	getline (unaligned, row2, row_delim);
       
       if(row[0]=='@'){
       
      	for(int j=0; j<numNodes; j++){
      		alignedFiles[j]<<row<<endl;
      		unalignedFiles[j]<<row2<<endl;
      		}
      		
      	continue;
      }

      // reset vector
      curr.clear ();
      istringstream ss (row);
      for (string word; getline (ss, word, field_delim);)
	{

	  curr.push_back (word);
	}
	
	/////write to the chromosome relevant file (field 2)
	alignedFiles[ chromMap[curr[2]] ]<<row<<endl;
	unalignedFiles[ chromMap[curr[2]] ]<<row2<<endl;
	
	} /////END of writing phase.
	
	///////CLOSE FILES.
	aligned.close();
	unaligned.close();
	
	for(int j=0; j<numNodes; j++){
		alignedFiles[j].close();
		unalignedFiles[j].close();
	}
	


  return ;
}

