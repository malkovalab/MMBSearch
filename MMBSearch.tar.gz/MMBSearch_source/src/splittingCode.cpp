




#include "defs.h"

#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <vector>
#include <sstream>
#include <sys/wait.h>
#include<string>
#include <stdlib.h>
#include <algorithm>
#include <limits.h>
#include <ctime>
#include <cmath>
#include <map>

using namespace std;



template <typename T>
  string NToString ( T Number )
  {
    ostringstream ss;
    ss << Number;
    return ss.str();
  }


string processFileName(string s, int id){
    if (id <10)
	return (s+"000"+NToString(id));
    if (id <100)
	return (s+"00"+NToString(id));
    if (id <1000)
	return (s+"0"+NToString(id));

    return (s+NToString(id));
    
}




void splitSecPhase()
{
  ifstream input;
  char row_delim = '\n';
  char field_delim = '\t';
  string previous="";
  string prevName = "";
  //input.open ((sProjectDirectory + sUnalignedFile).c_str ());
  ofstream output;
  output.open((confDB.getKey("projectDirectory").stringVal+"tempUnaligned").c_str());
  input.open ((confDB.getKey("projectDirectory").stringVal+confDB.getKey("unalignedFile").stringVal+"_2.sam").c_str());
  vector < string > curr;
  vector < string > curr2;
  string row;
  for (row; getline (input, row, row_delim);)
    {
       
       if(row[0]=='@'){
      	output<<row<<endl;
      	continue;
      }

      // reset vector
      curr.clear ();
      istringstream ss (row);
      for (string word; getline (ss, word, field_delim);)
	{

	  curr.push_back (word);
	}

      
     ////////////////////////////////////////////////////////////////////////////
     
     if(curr[0].erase(curr[0].size()-2).compare(prevName) == 0)    ///both belong to the same parent read
     {
     	prevName = "";
     	previous = "";
     	continue;
     }
     else{
  
     	if(previous.compare("") != 0)   //not an empty string
     	{	
     		output<<previous<<endl;
     	}
     	
     	previous = row;
     	prevName = curr[0];
     
     }
     
     /////////////////////////////////////////////////////////////////////////////

    }
    
    if(previous.compare("")!=0)  //write the last row
    	output<<previous<<endl; ///////////////////////%%%%%%%%%%%%%%%%%%% CHECK IF ENDL IS NEEDED
    
    input.close();
    output.close();

////////////////////////////////////////// END OF WRITING FIRST file /////////////////////////////////////


///////////////////////////////////////// START OF WRITING SECOND //////////////////////////////////////////
 previous="";
  prevName = "";
  //input.open ((sProjectDirectory + sUnalignedFile).c_str ());
  
  output.open((confDB.getKey("projectDirectory").stringVal+"tempAligned").c_str());
  input.open ((confDB.getKey("projectDirectory").stringVal+confDB.getKey("finalAlignedFile").stringVal+".sam").c_str());
 

  for (row; getline (input, row, row_delim);)
    {
      // ++index;

      //   if (index % 10000000 == 0)
      //    cout << "half-read: " << index << endl;
       
       if(row[0]=='@'){
      	output<<row<<endl;
      	continue;
      }

      // reset vector
      curr.clear ();
      istringstream ss (row);
      for (string word; getline (ss, word, field_delim);)
	{

	  curr.push_back (word);
	}
      //cout << row << endl;
      
     ////////////////////////////////////////////////////////////////////////////
     
     if(curr[0].erase(curr[0].size()-2).compare(prevName) == 0)    ///both belong to the same parent read
     {
     	prevName = "";
     	previous = "";
     	continue;
     }
     else{
  
     	if(previous.compare("") != 0)   //not an empty string
     	{	
     		output<<previous<<endl;
     	}
     	
     	previous = row;
     	prevName = curr[0];
     
     }
     
     /////////////////////////////////////////////////////////////////////////////

    }
    
    if(previous.compare("")!=0)  //write the last row
    	output<<previous<<endl; ///////////////////////%%%%%%%%%%%%%%%%%%% CHECK IF ENDL IS NEEDED
    
    input.close();
    output.close();
    
    ///// After writing the new files, remove old ones, and rename the new ones.

    string command = "rm "+confDB.getKey("projectDirectory").stringVal+confDB.getKey("finalAlignedFile").stringVal+".sam";
    system(command.c_str());
         command = "rm "+confDB.getKey("projectDirectory").stringVal+confDB.getKey("unalignedFile").stringVal+"_2.sam";
    system(command.c_str());
    
    command = "mv "+confDB.getKey("projectDirectory").stringVal+"tempAligned "+confDB.getKey("finalAlignedFile").stringVal+".sam";
    system(command.c_str());
    command = "mv "+confDB.getKey("projectDirectory").stringVal+"tempUnaligned "+confDB.getKey("unalignedFile").stringVal+"_2.sam";
    system(command.c_str());
    
        
    
    

/////////////////////////////////////// DONE THROWING DUPLICATES FROM aligned and unaligned files ////////////////////

////////////////////////////////////// START SPLITTING INTO DIFFERENT FILES before starting MPI processes ///////////////

	// First: count number of characters in the reference file
	//confDB.getKey("referenceFile").stringVal;
	 command = "wc -m < "+confDB.getKey("referenceFile").stringVal;
	long long int  numChars = system(command.c_str());
	//long long int numChars; 
       // sscanf(res, "%lld", &numChars);
	
	int numNodes = confDB.getKey("numNodesSec").intVal;
	long long int range = numChars / (numNodes + 1);
	
	///// Second: open unaligned and aligned files as inputs:
	ifstream aligned;
	ifstream unaligned;
	
	aligned.open((confDB.getKey("projectDirectory").stringVal+confDB.getKey("finalAlignedFile").stringVal+".sam").c_str());

	unaligned.open((confDB.getKey("projectDirectory").stringVal+confDB.getKey("unalignedFile").stringVal+"_2.sam").c_str());
	
	//Third: open the output files for each processor employed.
	
	ofstream alignedFiles[numNodes];
	ofstream unalignedFiles[numNodes];
	
	for(int i = 0; i< numNodes; i++){
		ostringstream filename;
		string fn = processFileName(confDB.getKey("projectDirectory").stringVal+confDB.getKey("finalAlignedFile").stringVal, i);
		
		filename << fn<<".sam";
		alignedFiles[i].open(filename.str().c_str());
	}
	
	for(int i = 0; i< numNodes; i++){
		ostringstream filename;
		string fn = processFileName(confDB.getKey("projectDirectory").stringVal+confDB.getKey("unalignedFile").stringVal, i);
		
		filename << fn<<"_2.sam";
		unalignedFiles[i].open(filename.str().c_str());
	}

	
	/////Start writing
	string row2;
	
	for (row; getline (aligned, row, row_delim);)
    {
    	getline (unaligned, row2, row_delim);
       
       if(row[0]=='@'){
       
      	for(int j=0; j<numNodes; j++){
      		alignedFiles[j]<<row<<endl;
      		unalignedFiles[j]<<row2<<endl;
      		}
      		
      	continue;
      }

      // reset vector
      curr.clear ();
      istringstream ss (row);
      for (string word; getline (ss, word, field_delim);)
	{

	  curr.push_back (word);
	}

	
	////Check the range of the read
	for(int j=0; j<numNodes; j++){
	
		if( atoi(curr[3].c_str()) <= ((j+1) * range))
		{ 
			alignedFiles[j]<<row<<endl;
			unalignedFiles[j]<<row2<<endl;
			break;	
		}
	
	}
	
	} /////END of writing phase.
	
	///////CLOSE FILES.
	aligned.close();
	unaligned.close();
	for(int j=0; j<numNodes; j++){
		alignedFiles[j].close();
		unalignedFiles[j].close();
	}

  return ;


}

