/*
 * templateFinder.cpp
 *
 *  Created on: Feb 4, 2013
 *      Author: msegar
 */


#include "defs.h"

#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <sys/wait.h>
#include <stdlib.h>
#include <algorithm>
#include <limits.h>
#include <ctime>
#include <cmath>

using namespace std;

void templateFinderHelper(){


}
// templateFinder
int startTemplateFinder(){
	cout << "\nStarting template finder ..." << endl;
	fLogFileOut << "\nStarting template finder ..." << endl;

	ofstream output;
	output.open((sProjectDirectory+ "final_bir_locs.txt").c_str());
	
	ofstream outputNoTemp; //this file contains birs and consensus with no temp found 
	outputNoTemp.open((sProjectDirectory+confDB.getKey("birWithNoTemplateFile").stringVal).c_str());
	
	string sBir;
	string sReference;
	string sBirReversed;
	int iBirStart = 0;
	int iTemplateSearchDistance = confDB.getKey("searchLength").intVal;
	int iMinBirLength = confDB.getKey("minBirLength").intVal;
	//int iMinBirLength = 13;
	int iChr = 0;
	t_alignment_struct tAligned;
	int iSize = vCandidateRegions.size();
	int tenPercent = iSize / 10;

	// statistics variables
	int skipped_short = 0;
	int skipped_stdev = 0;
	int iDepth;
	
	//Added 
	string chromosome = "";
	string command;
	int readEnd ;
	
	 string micHomInsertion;
	 string micHomTemplate;
	string result;
	string seq1="", seq2="", token="";
	 string findMicHomResult;
	 		
 enum tempKind {inverted=0, direct=1};
	int turn;

	
	// for the candidate regions with the bBirCandidateFound flag set to TRUE...
	for (unsigned int i = 0; i < iSize; ++i){
		if (i % tenPercent == 0)
			cout << "template: " << (i+1) << " of " << iSize << " (" << ((i * 100) / iSize) << "%)" << endl;
		if (!vCandidateRegions[i].bBirCandidateFound)
					continue;
		iChr = vCandidateRegions[i].iChromosome;
		iBirStart = vCandidateRegions[i].iBirStart;
		sBir = vCandidateRegions[i].sBir;
		sBirReversed = getReverseComplement(sBir);
		iDepth = vCandidateRegions[i].depth;
		chromosome  = vReferenceGenome[iChr].fastaHeader;
		
		//add a check if the range actually exists
		if( (iBirStart - iTemplateSearchDistance - 1) < 0){
			++skipped_stdev;
			continue;
		}
		
		turn = inverted;
		for(turn =0 ; turn<direct; turn= turn+1){
		
			//// New modification to use samtools to pull reference from multi chromo reference
			//sReference = vReferenceGenome[iChr].sequence.substr(iBirStart - iTemplateSearchDistance - 1, iTemplateSearchDistance);
			     //Modified readEnd to include the area left to insertion, and right area too. 
			readEnd = vCandidateRegions[i].iBirStart - 1 + sBir.length()+confDB.getKey("searchLength").intVal;
			command = "./samtools faidx "+confDB.getKey("referenceFile").stringVal+" "+chromosome+":"+NToString(vCandidateRegions[i].iParentStart)+"-"+NToString(readEnd);
			sReference = exec(command.c_str());
			//cout<<"TemplateFinder----------\n"<<command<<endl<<"iBirStart: "<<iBirStart<<endl<<sReference<<endl<<"sBir:\n"<<sBir<<"sBirReversed: "<<sBirReversed<<endl;
			sReference = procSamtools(sReference);
			///////////// End of modification
			
			transform(sReference.begin(), sReference.end(),sReference.begin(), ::toupper);
			
			/*cout << "iChr: " << iChr << endl;
			cout << "iBirStart: " << iBirStart << endl;
			cout << "sBir: " << sBir << endl;
			cout << "sBirReversed: " << sBirReversed << endl;
			cout << "sReference: " << sReference << endl;
			*/
			//New change to look for inverted and direct template
			if(turn == inverted){
				tAligned = getLocalAlignment(sReference, sBirReversed, confDB.getKey("gapOpen").doubleVal, confDB.getKey("gapExtend").doubleVal);
			}
			else{
				tAligned = getLocalAlignment(sReference, sBir, confDB.getKey("gapOpen").doubleVal, confDB.getKey("gapExtend").doubleVal);
			}
			//printAlignment(cout, sBirReversed, sReference, iBirStart, tAligned);
	
			vCandidateRegions[i].sTemplate = tAligned.sAlignedRegionJ + sBirReversed[sBirReversed.length()-1];
	
			if ((int) vCandidateRegions[i].sTemplate.length() < iMinBirLength){
				++skipped_short;
				continue;
			}
			//New modification to consider the length of the aligned part only, and making the 0.8 a config parameter
			//if ((sBir.length() * 0.8) > (int) vCandidateRegions[i].sTemplate.length()){ // TODO make 0.8 a config variable (80%)
			
			//if ((tAligned.sAlignedRegionI.length() * confDB.getKey("tempToBirPercentage").doubleVal) > (int) tAligned.sAlignedRegionJ.length()){ // TODO make 0.8 a config variable (80%)
			if ((sBir.length() * confDB.getKey("tempToBirPercentage").doubleVal) > (int) tAligned.sAlignedRegionJ.length()){ // TODO make 0.8 a config variable (80%)
				++skipped_stdev;
				outputNoTemp<<"\n cluster "<<i<<": \n"<<"sBir "<<tAligned.sAlignedRegionI<<endl<<"consensus: "<<tAligned.sAlignedRegionJ<<endl;
				continue;
			}
	
	
			vCandidateRegions[i].iTemplateStart = iBirStart - iTemplateSearchDistance - 1 + tAligned.iStartPosJ;
			vCandidateRegions[i].iTemplateEnd = iBirStart - iTemplateSearchDistance - 1 + tAligned.iEndPosJ;
	
			//output << "iChr: " << iChr << endl;
			output <<"\n####\n";
			output << "iBirStart: " << iBirStart << endl;
			output << "Consensus/cluster number: " <<i<< endl;
			output <<"iDepth: "<<iDepth<<endl; 
			output << "sBir: " << sBir << endl;
			output << "sBirReversed: " << sBirReversed << endl;
			if(turn == 0)
				output<< "Inverted template\n";
			else output<< "Direct template\n";
			output << "ref: " << sReference << endl;
			output << "bir: " << vCandidateRegions[i].sParentRead << endl;
			output << "TEM: " << vCandidateRegions[i].sTemplate << endl;
			
			//// NEW CODE FOR Microhomology finding.
			// we need: bir (which is the sParentRead), ref (sReference), insertion (tAligned.sAlignedRegionJ), and template (tAligned.sAlignedRegionI). 
			if(turn == 0){
				//cout<<"calling findMicHomology on candidate i:"<<i<<endl;
				
				findMicHomResult = findMicHomology(vCandidateRegions[i].sParentRead, sReference, tAligned, true, micHomInsertion, micHomTemplate); //inverted
				if(findMicHomResult.compare("Insertion is not found") != 0)
					output<<findMicHomResult<<endl;
			}else{
				//cout<<"calling findMicHomology on candidate i:"<<i<<endl;
				
				//findMicHomResult = findMicHomology(vCandidateRegions[i].sParentRead, sReference, tAligned, false, micHomInsertion, micHomTemplate); //inverted
				//if(findMicHomResult.compare("Insertion is not found") != 0)
					//output<<findMicHomResult<<endl;
			}
			
			seq1="";
			seq2="";
			command = "echo \">Seq1\n"+micHomInsertion+"\" > "+sProjectDirectory+"s1.txt ; "+ "echo \">Seq2\n"+micHomTemplate+"\" > "+sProjectDirectory+"s2.txt";
	 		system(command.c_str());
			
			command = "needle -asequence "+sProjectDirectory+"s1.txt -bsequence "+sProjectDirectory+"s2.txt -gapopen 100 -gapextend 10 -auto -outfile "+sProjectDirectory+"waterOut.water; cat "+sProjectDirectory+"waterOut.water | grep -v '#' | grep Seq* ";
	 			result = exec(command.c_str()); //this function will catch and return the sequences printed to stdout
				//cout<<"Result:\n"<<result<<endl;
	 			//the listed sequences are saved in result
	 			istringstream iss(result);
	 			while(iss>>token){
	 				if(token.compare("Seq1") == 0 ){
	 					iss>>token;
	 					iss>>token;
	 					//seq1 = seq1+token.substr(0, token.size()-1);
	 					seq1 = seq1+token;
	 					iss>>token;
	 				}
	 				
	 				else if(token.compare("Seq2") == 0 ){
	 					iss>>token;
	 					iss>>token;
	 					//seq2 = seq2+token.substr(0, token.size()-1);
	 					seq2 = seq2+token;
	 					iss>>token;
	 				}
	 				
	 				
	 			}//end while
						/////End of new code
			printAlignment(output, sBirReversed, sReference, iBirStart, tAligned);
			//output<<endl;
			//output<<"Micro homology alignment\n";
			//output<<"+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"<<endl;
			
			vFinalBirLocs.push_back(vCandidateRegions[i]);
			
		}//inner for loop--turn
	}//outer for loop
	output.close();
	outputNoTemp.close();

	fLogFileOut << "\nFinal stats: " << endl;
	fLogFileOut << "  skipped (short): " << skipped_short << endl;
	fLogFileOut << "  skipped (stdev): " << skipped_stdev << endl;
	fLogFileOut << "  found: " << vFinalBirLocs.size() << endl;

	// print out the final BIR incidents found and the templates
	//printFinal();

	// print final time
	fLogFileOut << "\nFinal time: " << (int)time(NULL)-time0 << endl;

	// clear memory
	vCandidateRegions.clear();
	vFinalBirLocs.clear();

	return 0;
}


string getReverseComplement(string &str){
	string rev;

	for (unsigned int i = 0; i < str.length(); ++i){
		if (str[i] == 'A')
			rev = 'T' + rev;
		else if (str[i] == 'C')
			rev = 'G' + rev;
		else if (str[i] == 'G')
			rev = 'C' + rev;
		else if (str[i] == 'T')
			rev = 'A' + rev;
		else
			rev = 'N' + rev;
	}

	return rev;
}

string findMicHomology(string bir, string ref, t_alignment_struct tAligned, bool inverted, string& micHomInsertion, string& micHomTemplate)
{
	string insertion = tAligned.sAlignedRegionJ;
	string Temp = tAligned.sAlignedRegionI;
	
	//get reverse complement if inverted 
	if(inverted){
		insertion = getReverseComplement(insertion);
	}
	//cout<<"Insertion: "<<insertion<<endl;
	//cout<<"template: "<<Temp<<endl;
	int posInsertion;
	int posTemplate;
	
	int found = bir.find(insertion); 
    if (found == string::npos){
    	return "Insertion is not found";
    }
   // else 
   posInsertion = static_cast<int>( found);
    
    found = ref.find(Temp);
    if(found == string::npos)
    	return "Template is not found";
	//else 
		posTemplate = static_cast<int>( found);
	
	int leftCoordIns;
	int rightCoordIns;
	int leftCoordTemp;
	int rightCoordTemp;
	int preInsLength;
	int postInsLength;
	int preTempLength;
	
	//int 
	
	//get the area where we have the microhomology
	if(posInsertion < posTemplate){
		//micHomMiddle = bir.substr(posInsertion+insertion.size(), posTemplate); //get from the end of the insertion to start of template 
		if(posInsertion > 8){
			//micHomLeftInsertion = bir.substr(posInsertion-8, 8);
			leftCoordIns = posInsertion-8;
			preInsLength = 8;
		}
		else{
			//micHomLeftInsertion = bir.substr(0, posInsertion); 
			leftCoordIns = 0;
			if(posInsertion > 0)
				preInsLength = posInsertion-1;
			else preInsLength =0;
		}
		if( (posTemplate -  static_cast<int>(posInsertion+insertion.size())) > 16){
			//micHomRightInsertion = bir.substr(posInsertion+insertion.size() , 8 );
			rightCoordIns = preInsLength + insertion.size() + 8;
		}
		else{
			//micHomRightInsertion = bir.substr( (posInsertion+insertion.size()), (posTemplate - (posInsertion+insertion.size()))/2);
			rightCoordIns = preInsLength + insertion.size() + ((posTemplate - (posInsertion+insertion.size()))/2);
			
		}
		//cout<<"DEBUGGING........ posInsertion < posTemplate:\n"; 
		//cout<<"leftCoordIns: "<<leftCoordIns<<"  rightCoordIns: "<<rightCoordIns<<endl;
		micHomInsertion = bir.substr( leftCoordIns,  rightCoordIns-1);
		//cout<<"1- Left  and right insertions\n";
		
		if( posTemplate -  static_cast<int>(posInsertion+insertion.size()) > 16){
			//micHomLeftTemp = ref.substr(posTemplate - 8, 8);
			leftCoordTemp = posTemplate - 8;
			preTempLength = 8;
		}
		else{
		 	//micHomLeftTemp = ref.substr( posTemplate - (posTemplate - (posInsertion+insertion.size()))/2,  (posTemplate - (posInsertion+insertion.size()))/2);
			leftCoordTemp = posTemplate - ((posTemplate - (posInsertion+insertion.size()))/2);
			preTempLength = (posTemplate - (posInsertion+insertion.size()))/2;
			if(leftCoordTemp < 0){
				leftCoordTemp = 0;
				//preTempLength = posTemplate-1;
				if(posTemplate == 0)
					preTempLength = 0; 
				else preTempLength = posTemplate - 1;
			}
		}
		if(ref.size() -  static_cast<int>(posTemplate+Temp.size()) >8 ){
			//micHomRightTemp = ref.substr(posTemplate+Temp.size(), 8);
			rightCoordTemp = preTempLength + Temp.size() + 8;
		}
		else{ 
			//micHomRightTemp = ref.substr(posTemplate+Temp.size());
			rightCoordTemp = ref.size() - leftCoordTemp; //+ preTempLength + Temp.size());
		}
		//cout<<"DEBUGGING........ posInsertion < posTemplate:\n"; 
		//cout<<"leftCoordTemp: "<<leftCoordTemp<<"  rightCoordTemp: "<<rightCoordTemp<<endl;
		micHomTemplate = ref.substr(leftCoordTemp , rightCoordTemp-1);
		micHomTemplate = getReverseComplement(micHomTemplate );
		 
		//cout<<"1- Left  and right template\n";
	}
	else{
	
		if(posTemplate > 8){
			//micHomLeftInsertion = bir.substr(posInsertion-8, 8);
			leftCoordTemp = posTemplate-8;
			preTempLength = 8;
		}
		else{
			//micHomLeftInsertion = bir.substr(0, posInsertion); 
			leftCoordTemp = 0;
			//preTempLength = posTemplate-1;  //Check if it is just posTemplate, without -1
			if(preTempLength == 0)
				preTempLength = 0;
			else preTempLength = posTemplate - 1;
		}
		if(posInsertion - static_cast<int>(posTemplate+Temp.size()) > 16){
			//micHomRightInsertion = bir.substr(posInsertion+insertion.size() , 8 );
			rightCoordTemp = preTempLength + Temp.size() + 8;
		}
		else{
			//micHomRightInsertion = bir.substr( (posInsertion+insertion.size()), (posTemplate - (posInsertion+insertion.size()))/2);
			rightCoordTemp = preTempLength + Temp.size() + ((posInsertion - (posTemplate+Temp.size()))/2);
			
		}
		
		//cout<<"DEBUGGING........ posInsertion > posTemplate:\n"; 
		//cout<<"leftCoordTemp: "<<leftCoordTemp<<"  rightCoordTemp: "<<rightCoordTemp<<endl;
		micHomTemplate  = ref.substr( leftCoordTemp,  rightCoordTemp-1);
		micHomTemplate = getReverseComplement(micHomTemplate);
		//cout<<"1- Left  and right insertions\n";
		
		if( posInsertion -  static_cast<int>(posTemplate+Temp.size()) > 16){
			//micHomLeftTemp = ref.substr(posTemplate - 8, 8);
			leftCoordIns = posInsertion - 8;
			preInsLength = 8;
		}
		else{
		 	//micHomLeftTemp = ref.substr( posTemplate - (posTemplate - (posInsertion+insertion.size()))/2,  (posTemplate - (posInsertion+insertion.size()))/2);
			leftCoordIns = posInsertion - ((posInsertion - (posTemplate+Temp.size()))/2);
			preInsLength = (posInsertion - (posTemplate+Temp.size()))/2;
			if(leftCoordIns <0){
				leftCoordIns = 0;
				
				if(preInsLength <0)
					preInsLength = 0;
				else preInsLength = posInsertion - 1;
			}
		}
		if(bir.size() - static_cast<int>(posInsertion+insertion.size()) >8 ){
			//micHomRightTemp = ref.substr(posTemplate+Temp.size(), 8);
			rightCoordIns = preInsLength + insertion.size() + 8;
		}
		else{ 
			//micHomRightTemp = ref.substr(posTemplate+Temp.size());
			rightCoordIns = bir.size() - leftCoordIns; 
		}
		
		//cout<<"DEBUGGING........ posInsertion < posTemplate:\n"; 
		//cout<<"lefttCoordIns: "<<leftCoordIns<<"  rightCoordIns: "<<rightCoordIns<<endl;
	
		micHomInsertion = bir.substr(leftCoordIns , rightCoordIns-1);
		//cout<<"1- Left  and right template\n";
	}
	
	return "Microhomology Insertion: "+micHomInsertion+"\nMicrohomology template: "+micHomTemplate;
}

/*

	//get the area where we have the microhomology
	if(posInsertion < posTemplate){
		//micHomMiddle = bir.substr(posInsertion+insertion.size(), posTemplate); //get from the end of the insertion to start of template 
		if(posInsertion > 7)
			micHomLeftInsertion = bir.substr(posInsertion-8, 8);
		else
			micHomLeftInsertion = bir.substr(0, posInsertion); 
		
		if(posTemplate - (posInsertion+insertion.size()) > 16)
			micHomRightInsertion = bir.substr(posInsertion+insertion.size() , 8 );
		else
			micHomRightInsertion = bir.substr( (posInsertion+insertion.size()), (posTemplate - (posInsertion+insertion.size()))/2);
		
		cout<<"1- Left  and right insertions\n";
		
		if( posTemplate - (posInsertion+insertion.size()) > 16)
			micHomLeftTemp = ref.substr(posTemplate - 8, 8);
		else micHomLeftTemp = ref.substr( posTemplate - (posTemplate - (posInsertion+insertion.size()))/2,  (posTemplate - (posInsertion+insertion.size()))/2);
		
		if(ref.size() - posTemplate+Temp.size() >8 )
			micHomRightTemp = ref.substr(posTemplate+Temp.size(), 8);
		else 
			micHomRightTemp = ref.substr(posTemplate+Temp.size());
			
		cout<<"1- Left  and right template\n";
	}
	else{
		if(posTemplate > 7)
			micHomLeftTemp = ref.substr(posTemplate-8, 8);
		else
			micHomLeftTemp = ref.substr(0, posTemplate); 
		
		if(posInsertion - (posTemplate+Temp.size()) > 16)
			micHomRightTemp = ref.substr(posTemplate+Temp.size() , 8 );
		else
			micHomRightTemp = ref.substr( (posTemplate+Temp.size()), (posInsertion - (posTemplate+Temp.size()))/2);
		
		cout<<"2- Left  and right insertions\n";
		
		if( posInsertion - (posTemplate+Temp.size()) > 16){
			micHomLeftInsertion = bir.substr(posInsertion - 8, 8);
			cout<<"2- Left  and right postInsertion I\n";
		}
		else micHomLeftInsertion = bir.substr( posInsertion - (posInsertion - (posTemplate+Temp.size()))/2,  (posInsertion - (posTemplate+Temp.size()))/2);
		
		cout<<"2- Left  and right postInsertion IIII\n";
		
		if(bir.size() - posInsertion+insertion.size() > 8)
			micHomRightInsertion = bir.substr(posInsertion+insertion.size(), 8);
		else
			micHomRightInsertion = bir.substr(posInsertion+insertion.size());
		
		cout<<"2- Left  and right template\n";
	}
	
	return micHomLeftInsertion+"\n"+micHomRightInsertion+"\n"+micHomLeftTemp+"\n"+micHomRightTemp+"\n";
*/