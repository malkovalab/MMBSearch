if [ $# != "1" ] || [ $1 = "-h" ] || [ $1 = "--help" ]; then
        echo "$0 [PATH TO SPLIT ALIGNMENT DIRECTORY]"
        echo "Sort chromosomal split results into chromosomal directories"
        echo ""
        exit 1
fi

n=1;
max=25;
while [ "$n" -le "$max" ]; do
  mkdir "$1/chr${n}"
  i=`expr "$n" - 1`
  mv $1/*"00${i}_"* "$1/chr${n}"
  mv $1/*"00${i}."* "$1/chr${n}"
  n=`expr "$n" + 1`;
done

