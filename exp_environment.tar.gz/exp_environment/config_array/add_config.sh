#Add a new parameter to the configuration files (Only needed if MMBSearch source code was changed!)
#Put new parameter to be added in a file called "new_config.txt". It will be concatinated to the end of the config files. 

for n in {1..25..1}; do
	for f in config1316-chr${n}.txt ; do
		head -92 $f > temp1.txt
		cat new_config.txt >> temp1.txt
		tail -79 $f >> temp1.txt
		mv temp1.txt config1404-chr${n}.txt
	done
done
