#!/bin/bash

if [ $# != "2" ] || [ $1 = "-h" ] || [ $1 = "--help" ]; then
        echo "$0 Sample1_Dir Sample2_Dir"
        echo "Compare sample1 Final_locs file to sample2 consensus file"
        echo ""
        echo ""
        exit 1
fi

#> foundDups.txt

s1dir=$1
s2dir=$2

echo "Searching for commons between $1 and $2 ..."

for i in {1..25}; do 
	python3 findCommonsV6.py $s1dir/chr$i/final_bir_locs.txt $s2dir/chr$i/consensus_reads.txt  
	mv commons.txt $s1dir/chr$i/
	mv non_commons.txt $s1dir/chr$i/
done


